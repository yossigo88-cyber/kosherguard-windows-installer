"""KosherGuard desktop setup. Preview mode never imports USB libraries or calls services."""
import argparse, asyncio, queue, threading, time, os, sys
import tkinter as tk
from tkinter import ttk, messagebox
import updater
import setup_engine as engine
import usb_engine as usb
DARK='#102341'; NAVY='#142f59'; BLUE='#2475cf'; LIGHT='#eef5fe'; WHITE='#ffffff'; INK='#203047'; MUTED='#63758b'; RED='#b92832'; GREEN='#187752'

def requests_session():
    import requests
    return requests

class App:
    def __init__(self, preview=False):
        self.preview=preview; self.busy=False; self.q=queue.Queue(); self.info=None;self.dev=None;self.options={};self.started=None
        self.root=tk.Tk();self.root.title('KosherGuard PC Setup');self.root.geometry('760x820');self.root.minsize(640,560);self.root.configure(bg=WHITE)
        self.root.protocol('WM_DELETE_WINDOW',self.close)
        self.loop=asyncio.new_event_loop();threading.Thread(target=self.loop.run_forever,daemon=True).start()
        h=tk.Frame(self.root,bg=DARK,padx=28,pady=17);h.pack(fill='x')
        tk.Label(h,text='✦',font=('Segoe UI',22,'bold'),fg='#6db9ff',bg=DARK).pack(side='left')
        tk.Label(h,text='  KosherGuard',font=('Segoe UI',20,'bold'),fg=WHITE,bg=DARK).pack(side='left')
        tk.Label(h,text='PC SETUP',font=('Segoe UI',10,'bold'),fg='#b9d2f1',bg=DARK).pack(side='right')
        footer='PREVIEW ONLY • Sample phone • No USB or network' if preview else 'Free • Local USB setup • Test build 15'
        tk.Label(self.root,text=footer,font=('Segoe UI',9),bg=LIGHT,fg=MUTED,pady=12).pack(side='bottom',fill='x')
        w=tk.Frame(self.root,bg=WHITE);w.pack(fill='both',expand=True)
        self.canvas=tk.Canvas(w,bg=WHITE,highlightthickness=0);sb=tk.Scrollbar(w,command=self.canvas.yview);sb.pack(side='right',fill='y');self.canvas.pack(side='left',fill='both',expand=True);self.canvas.configure(yscrollcommand=sb.set)
        self.content=tk.Frame(self.canvas,bg=WHITE,padx=38,pady=24);win=self.canvas.create_window(0,0,window=self.content,anchor='nw')
        self.content.bind('<Configure>',lambda e:self.canvas.configure(scrollregion=self.canvas.bbox('all')))
        self.canvas.bind('<Configure>',lambda e:self.canvas.itemconfigure(win,width=e.width))
        self.root.bind_all('<MouseWheel>',lambda e:self.canvas.yview_scroll(-1 if e.delta>0 else 1,'units'))
        st=ttk.Style(self.root);st.theme_use('clam');st.configure('KG.Horizontal.TProgressbar',background=BLUE,troughcolor=LIGHT)
        self.root.after(100,self.pump);self.welcome()
        if not preview:self.root.after(1500,self.check_updates)
    def clear(self):
        for w in self.content.winfo_children():w.destroy()
        self.canvas.yview_moveto(0);self.screen_text=[]
    def label(self,text,size=12,color=INK,bold=False):
        if not hasattr(self,'screen_text'):self.screen_text=[]
        self.screen_text.append(str(text))
        x=tk.Label(self.content,text=text,font=('Segoe UI',size,'bold' if bold else 'normal'),bg=WHITE,fg=color,wraplength=620,justify='left',anchor='w')
        def menu(e,t=str(text)):
            m=tk.Menu(x,tearoff=0)
            m.add_command(label='Copy this text',command=lambda:(self.root.clipboard_clear(),self.root.clipboard_append(t)))
            m.add_command(label='Copy everything on this screen',command=self.copy_all)
            m.tk_popup(e.x_root,e.y_root)
        x.bind('<Button-3>',menu)
        x.pack(fill='x',pady=(0,12));return x
    def select_box(self,text,height=8):
        """Fixed-size read-only box: drag to select, Ctrl+C to copy. No resize callbacks."""
        self.screen_text.append(str(text))
        f=tk.Frame(self.content,bg=WHITE);f.pack(fill='x',pady=(0,12))
        t=tk.Text(f,font=('Consolas',10),bg='#f4f7fb',fg=INK,wrap='word',height=height,width=70,bd=1,relief='solid')
        sb=tk.Scrollbar(f,command=t.yview);t.configure(yscrollcommand=sb.set)
        sb.pack(side='right',fill='y');t.pack(side='left',fill='x',expand=True)
        t.insert('1.0',str(text))
        def block(e):
            if e.state&0x4 and e.keysym.lower() in ('c','a'):return None
            if e.keysym in ('Left','Right','Up','Down','Prior','Next','Home','End'):return None
            return 'break'
        t.bind('<Key>',block)
        t.bind('<Control-a>',lambda e:(t.tag_add('sel','1.0','end'),'break')[1])
        return t
    def copy_all(self):
        txt='\n'.join(getattr(self,'screen_text',[]))
        try:
            lp=usb.log_path();tail=lp.read_text(errors='replace').splitlines()[-60:] if lp.exists() else []
        except Exception:tail=[]
        if tail:txt+='\n\n--- log tail ---\n'+usb._redact('\n'.join(tail))
        self.root.clipboard_clear();self.root.clipboard_append(txt);self.root.update()
        messagebox.showinfo('Copied','Everything on this screen and the end of the log is copied. Paste it into WhatsApp.')
    def copy_button(self):self.button('Copy all text + log',self.copy_all,MUTED)
    def title(self,text):return self.label(text,22,DARK,True)
    def button(self,text,fn,color=BLUE):
        b=tk.Button(self.content,text=text,command=fn,bg=color,fg=WHITE,activebackground=NAVY,activeforeground=WHITE,font=('Segoe UI',12,'bold'),relief='flat',padx=20,pady=12,wraplength=580,justify='left',cursor='hand2');b.pack(anchor='w',pady=(7,7));return b
    def entry(self,text,show=None,value=''):
        self.label(text,10,INK,True);e=tk.Entry(self.content,font=('Segoe UI',12),show=show,relief='solid',bd=1);e.pack(fill='x',ipady=7,pady=(0,13));e.insert(0,value);return e
    def check(self,text,var):
        tk.Checkbutton(self.content,text=text,variable=var,font=('Segoe UI',11),bg=WHITE,fg=INK,wraplength=605,justify='left',anchor='w').pack(fill='x',pady=(2,9))
    def submit(self,coro,done):
        if self.busy:return
        self.busy=True
        f=asyncio.run_coroutine_threadsafe(coro,self.loop)
        def complete(f):
            try:self.q.put(('done',(done,f.result())))
            except Exception as e:self.q.put(('error',e))
        f.add_done_callback(complete)
    def pump(self):
        try:
            while True:
                kind,v=self.q.get_nowait()
                if kind=='done':self.busy=False;v[0](v[1])
                elif kind=='error':self.busy=False;self.error(v)
                elif kind=='update':
                    if not self.busy and v:self.offer_update(v)
                elif kind=='progress':
                    text,pct=v
                    if hasattr(self,'status') and self.status.winfo_exists():self.status.config(text=text)
                    if pct is not None and hasattr(self,'bar') and self.bar.winfo_exists():self.bar.stop();self.bar.config(mode='determinate',value=pct)
                elif kind=='step':
                    if hasattr(self,'step_label') and self.step_label.winfo_exists():self.step_label.config(text='\n'.join(('✓ ' if i<v else '➜ ' if i==v else '    ')+x for i,x in enumerate(engine.STEPS)))
        except queue.Empty:pass
        self.root.after(100,self.pump)
    def progress(self,text,pct=None):self.q.put(('progress',(text,pct)))
    def welcome(self):
        self.clear();self.title('Set up a protected iPhone')
        self.label('Connect ONE iPhone to this Windows PC with a USB cable. Unlock it and tap "Trust This Computer" if asked.')
        self.label('This test build erases the phone. Use only your own test phone.',12,RED,True)
        self.label('Our own KosherGuard MDM. No Apple Business enrollment or third-party MDM. No phone changes happen during discovery.')
        self.button('Find my iPhone  →',self.find)
        self.button('Open KosherGuard dashboard',lambda:self.open_url(engine.BASE),NAVY)
        self.label('Apple Devices from Microsoft Store supplies the USB driver. A data-capable cable is required.',10,MUTED)
    def open_url(self,url):
        if not self.preview:
            import webbrowser;webbrowser.open(url)
    def sample(self):return {'name':'Spare iPhone','model':'iPhone 8','ios':'16.7','serial':'SAMPLE-ONLY','supervised':False,'activated':True,'pf':{'space_msg':'Sample: 100 GB free on this PC.','encrypted':False}}
    def find(self):
        if self.preview:self.info=self.sample();return self.found(self.info)
        self.working('Checking the USB connection…')
        async def job():
            if self.dev:await self.dev.close()
            self.dev=usb.RealDevice()
            try:
                i=await asyncio.wait_for(self.dev.find(),60)
                i['pf']=await asyncio.wait_for(self.dev.preflight(),60)
            except asyncio.TimeoutError:
                raise usb.SetupError('The phone did not answer within a minute. Unplug and replug the cable, unlock the iPhone, tap Trust if asked, then click Check again. Nothing was changed.')
            return i
        self.submit(job(),self.found)
    def found(self,info):
        self.info=info;self.clear();self.title('Your iPhone is connected')
        self.label(f"{info['name']}  ·  {info['model']}  ·  iOS {info['ios']}",15,DARK,True)
        sup=info.get('supervised');self.label('Supervised: '+{True:'Yes',False:'No',None:'could not confirm'}[sup],13,DARK,True)
        self.label('Customer details will be linked to this detected phone after you approve it in your dashboard.')
        self.label(info.get('pf',{}).get('space_msg',''),11,MUTED)
        saved=engine.load_state() if not self.preview else {}
        if sup is True:
            self.label('Phone is supervised. No erase is needed.',12,GREEN,True)
            self.button('Continue: install MDM + lock tests (NO erase)  →',self.resume_details,RED)
            self.button('Remove test restrictions from the phone (no erase)',self.remove_tests,NAVY)
            self.button('LAB: MDM install-shape tests (no erase)',self.lab,NAVY)
        elif saved.get('experiment')=='fresh' and saved.get('udid')==info.get('serial') and saved.get('phase') in ('erased','supervised'):
            self.label('The phone was already erased by this app. Continue without erasing again.',12,RED,True)
            self.button('Continue setup (NO second erase)',lambda:self.fresh_details(True),RED)
        elif saved.get('experiment')=='fresh' and saved.get('udid')==info.get('serial') and saved.get('phase') in ('erase_requested','install_sent','installed'):
            self.label('Setup already started on this phone. To avoid a second erase, nothing more is offered. Look at the phone, then send me a photo and the local log.',12,RED,True)
        elif True:
            self.button('Set up this iPhone  →',self.fresh_details,RED)
        elif saved.get('udid')==info.get('serial') and saved.get('clean_start'):
            if saved.get('experiment')=='activation-incomplete' and saved.get('phase')=='erased':
                self.button('Continue timing TEST (NO SECOND ERASE)',lambda:self.activation_details(True),NAVY)
            elif saved.get('experiment')=='activation-incomplete' and saved.get('phase') in ('erase_requested','test_supervision','test_install_sent','test_installed'):
                self.label('This experiment already started. No repeat erase or failed install is offered. Inspect the phone and local log, then send screenshots.',12,RED,True)
            elif sup is True:
                self.button('NEW TEST: install before setup completes (ERASES)',self.activation_details,RED)
            else:
                self.label('Test requires the recorded supervised spare. No erase or install is offered.',12,RED,True)
        else:
            self.label('This build is only for the same owner spare iPhone 8 recorded by the earlier clean-start test. No setup changes are offered for other phones.',12,RED,True)
        self.button('Check the connected phone again',self.find,MUTED)
        self.button('Open local log folder',self.open_logs,MUTED)
    def resume_details(self):
        self.clear(); self.title('Continue on the supervised phone')
        self.label('No erase. FIRST on the iPhone: connect it to Wi-Fi and open Safari to check the internet works (the phone fetches its identity from our server during install; without internet iOS says A network error has occurred). The app installs the KosherGuard MDM profile (removable, because iOS refuses a locked MDM profile), checks in with the server, then tests a separate non-removable restrictions profile. Keep the cable plugged in.',11,INK)
        self.name=self.entry('Customer name',value='Sample Customer' if self.preview else '')
        self.phone=self.entry('Customer phone number',value='2125550100' if self.preview else '')
        def go():
            if self.preview:return self.working('Preview: continue')
            opts={'resume12':True,'extras':True}
            name,phone=self.name.get(),self.phone.get();self.working('Approve this phone in your dashboard')
            self.submit(engine.run_flow(self.dev,self.info,name,phone,opts,self.progress,lambda i:self.q.put(('step',i))),self.result)
        self.button('Install and test (no erase)',go,RED)
        self.button('Back',lambda:self.found(self.info),MUTED)
    def lab(self):
        self.clear();self.title('LAB: MDM install-shape tests')
        self.label('No erase. Each test first removes the MDM profile (the phone stays supervised), tries one install shape, and shows the exact answer from iOS plus the phone log. Afterwards press Restore to put the normal MDM back. Run one test, then send the result with the Copy button.',11,INK)
        self.label('KEYLESS tests (need no key, no removal; each shows an Install prompt on the iPhone that you must tap):',11,INK,True)
        for code,desc in engine.KEYLESS_SHAPES:
            self.button(code+': '+desc,lambda c=code:self.keyless_run(c),RED)
        self.label('Tests below need the supervision key on this PC:',11,MUTED,True)
        for code,desc in engine.LAB_SHAPES:
            self.button(code+': '+desc,lambda c=code:self.lab_run(c),RED)
        self.button('RESTORE: put the normal removable MDM back',lambda:self.lab_run('RESTORE'),GREEN)
        self.button('Back',lambda:self.found(self.info),MUTED)
    def keyless_run(self,code):
        if self.preview:return self.working('Preview: lab')
        self.working('Keyless test '+code)
        self.submit(engine.run_flow(self.dev,self.info,'','',{'lab':True,'keyless':True,'shape':code},self.progress,lambda i:self.q.put(('step',i))),self.result)
    def lab_run(self,code):
        if self.preview:return self.working('Preview: lab')
        self.working('Lab test '+code)
        self.submit(engine.run_flow(self.dev,self.info,'','',{'lab':True,'shape':code},self.progress,lambda i:self.q.put(('step',i))),self.result)
    def remove_tests(self):
        if self.preview:return
        self.working('Removing the test restrictions')
        self.submit(engine.remove_lock_test(self.dev,self.progress),self.result)
    def fresh_details(self, continuation=False):
        self.clear(); self.title('Set up this iPhone')
        self.label('The app will erase the phone, supervise it, install the one KosherGuard profile (set to not be removable) and check in with the server. No backup. Keep the cable plugged in the whole time.',11,INK)
        self.name=self.entry('Customer name',value='Sample Customer' if self.preview else '')
        self.phone=self.entry('Customer phone number',value='2125550100' if self.preview else '')
        self.fresh_consent=tk.BooleanVar(value=continuation)
        if not continuation:
            self.label('Everything on the phone will be erased.',12,RED,True)
            self.check('Erase this iPhone now. I understand all its data will be lost. Find My is off.',self.fresh_consent)
        def go():
            if self.preview:return self.working('Preview: set up')
            opts={'fresh':True,'consent':self.fresh_consent.get(),'skip_erase':continuation}
            name,phone=self.name.get(),self.phone.get();self.working('Approve this phone in your dashboard')
            self.submit(engine.run_flow(self.dev,self.info,name,phone,opts,self.progress,lambda i:self.q.put(('step',i))),self.result)
        self.button('Continue (no erase)' if continuation else 'Erase and set up',go,RED)
        self.button('Back',lambda:self.found(self.info),MUTED)
    def activation_details(self, continuation=False):
        self.clear(); self.title('One-profile timing test')
        self.label('OWNER SPARE iPHONE 8 ONLY. Experimental, not a working lock claim.',12,RED,True)
        self.label('Different from build 9: keep Setup Assistant incomplete while attempting the locked MDM profile. No second profile, removable fallback, activation bypass, or restore of the old backup. Apple may reject it again. Push delivery, app hiding and filtering are NOT verified by this test.',11,INK)
        self.name=self.entry('Customer name',value='Sample Customer' if self.preview else '')
        self.phone=self.entry('Customer phone number',value='2125550100' if self.preview else '')
        self.password=self.entry('Local backup password, if encrypted (stays on PC)',show='*')
        self.test_consent=tk.BooleanVar(value=False);self.test_backup=tk.BooleanVar(value=False)
        if not continuation:
            self.label('ALL phone data will be erased after a new local safety backup. Keep a separate usable backup too. Turn Find My off first. No automatic second erase.',12,RED,True)
            self.check('This is my own spare iPhone 8, Find My is OFF, and I approve erasing it.',self.test_consent)
            self.check('I saved what I need separately and accept losing all phone data.',self.test_backup)
        else:
            self.label('Continue only the recorded erased test. No erase or old backup restore. Stay in Setup Assistant.',12,RED,True)
        self.test_phrase=self.entry('Type CONTINUE' if continuation else 'Type TEST ERASE')
        def start_test():
            if self.preview:return self.working('Preview: activation timing test')
            opts={'activation_test':True,'activation_continue':continuation,'test_phrase':self.test_phrase.get(),
                  'consent':self.test_consent.get(),'backup_confirmed':self.test_backup.get(),'password':self.password.get()}
            name,phone=self.name.get(),self.phone.get();self.working('Approve the spare-phone test in your dashboard')
            self.submit(engine.run_flow(self.dev,self.info,name,phone,opts,self.progress,lambda i:self.q.put(('step',i))),self.result)
        self.button('Continue test (no erase)' if continuation else 'Back up, ERASE, then test',start_test,RED)
        self.button('Back',lambda:self.found(self.info),MUTED)

    def details(self,resume=None,transfer=False,continue_clean=False,password_test=False):
        self.password_test=password_test
        self.continue_clean=continue_clean
        self.transfer=transfer
        self.resume=resume if isinstance(resume,dict) else None;self.clear();self.title('Clean start: OWN spare phone only' if transfer else 'Set up this iPhone' if not self.resume else 'Resume without erasing')
        self.label('1. Customer details',13,DARK,True)
        self.name=self.entry('Customer name',value='Sample Customer' if self.preview else '')
        self.phone=self.entry('Customer phone number',value='2125550100' if self.preview else '')
        self.label('2. Your data',13,DARK,True)
        self.backup=tk.BooleanVar(value=True)
        if password_test:
            self.label('EXPERIMENT on your own spare only. iOS may reject this MDM + removal-password combination. No erase and no removable fallback. If accepted, a Remove button may remain. This is not a proven non-removable enrollment or dashboard-only removal. Save your recovery password privately.',11,RED,True)
            self.test_password=self.entry('Recovery password (12+ characters, keep privately)',show='*')
            self.test_phrase=self.entry('Type TEST to allow this experiment')
        elif continue_clean:
            self.label('On iPhone: press Home, choose language/region, Set Up Manually, then join Wi-Fi. Stay in Setup Assistant; do not restore a backup or finish to Home. Keep this PC online. Continue Apple activation, then verify old supervision is gone before fresh supervision. No erase, backup restore, or bypass is performed.',11,RED,True)
            self.continue_phrase=self.entry('At Hello/Setup Assistant: type CONTINUE WITHOUT ERASE')
        elif transfer:
            self.check('Keep a local safety backup (NOT restored automatically)',self.backup)
            self.label('This erases the old supervision and ALL phone data if iOS allows it. An old supervised backup can bring the old setup back, so this path starts fresh. Apple Account activation and any organization release are still required. This is not a bypass.',11,RED)
        elif self.info.get('supervised') is False and not self.resume:
            self.check('Make and restore a local PC backup before enrollment',self.backup)
            self.label('Restore leaves out management and selected system settings to preserve supervision. Apps may download again. This is not an identical copy of everything.',10,MUTED)
        elif self.resume:
            self.label('Uses the saved backup. No second erase will be sent.',11,MUTED)
        else:
            self.label('Already supervised: enrollment only. No backup, erase or restore.',11,MUTED)
        self.password=None
        if self.info.get('pf',{}).get('encrypted') or self.resume:
            self.password=self.entry('Encrypted backup password, if required (stays on this PC)',show='•')
        self.needs_erase=not password_test and not continue_clean and not self.resume and (self.info.get('supervised') is False or transfer)
        if self.needs_erase:
            self.label('3. Stop: this erases the iPhone',15,RED,True)
            self.consent=tk.BooleanVar(value=False);self.independent=tk.BooleanVar(value=False)
            self.check('Find My is OFF, and the phone owner agrees to erasing this phone.',self.consent)
            self.check('I saved what I need elsewhere and accept losing ALL phone data.' if transfer else 'I have a separate backup I know can be restored.',self.independent)
            self.erase=self.entry('Type ERASE to allow erasing after backup checks')
            if transfer:self.owner_phrase=self.entry('Type OWN SPARE ERASE to confirm this is your own spare phone')
        self.button('Start  →',self.start,GREEN);self.button('Back',lambda:self.found(self.info),MUTED)
    def start(self):
        if self.preview:return self.working('Preview: preparing setup')
        if self.busy:return
        if self.needs_erase and not (self.consent.get() and self.independent.get() and self.erase.get()=='ERASE'):
            return messagebox.showwarning('Before erasing','Tick both consent boxes and type ERASE exactly. Nothing was changed.')
        opts={'backup':self.backup.get(),'password':self.password.get() if self.password else '', 'consent':not self.needs_erase or self.consent.get(),'backup_confirmed':not self.needs_erase or self.independent.get(),'erase':self.erase.get() if self.needs_erase else '', 'resume':bool(self.resume)}
        if self.resume:opts.update(backup_dir=self.resume.get('backup_dir'),restore_done=self.resume.get('restore_done',False))
        if self.transfer:opts.update(transfer=True,owner_phrase=self.owner_phrase.get())
        if self.password_test:opts.update(password_test=True,test_password=self.test_password.get(),test_phrase=self.test_phrase.get())
        if self.continue_clean:opts.update(continue_clean=True,continue_phrase=self.continue_phrase.get())
        name,phone=self.name.get(),self.phone.get();self.working('Approve setup in your dashboard')
        self.submit(engine.run_flow(self.dev,self.info,name,phone,opts,self.progress,lambda i:self.q.put(('step',i))),self.result)
    def working(self,title='Setting up your iPhone…'):
        self.clear();self.title(title)
        self.label('Keep the cable connected. Watch for Trust, unlock or setup prompts on the phone.',11,INK)
        self.step_label=self.label('\n'.join('    '+s for s in engine.STEPS),12,MUTED)
        self.bar=ttk.Progressbar(self.content,mode='indeterminate',style='KG.Horizontal.TProgressbar');self.bar.pack(fill='x',pady=14);self.bar.start(15)
        self.status=self.label('Waiting for the next confirmed step…',12,INK)
        self.elapsed=self.label('',10,MUTED);self.started=time.monotonic();self._tid=getattr(self,'_tid',0)+1;self.tick(self._tid)
        self.label('No "locked" or "filter active" claim until the relevant device check succeeds.',10,MUTED)
    def tick(self,tid=None):
        if tid is not None and tid!=getattr(self,'_tid',0):return
        if hasattr(self,'elapsed') and self.elapsed.winfo_exists():
            n=int(time.monotonic()-self.started);self.elapsed.config(text=f'App is working  ·  {n//60:02}:{n%60:02} elapsed');self.root.after(1000,lambda:self.tick(tid))
    def phone_wait(self):
        self.clear();self.title('Finish setup on the iPhone')
        self.label('Keep USB connected. Follow the actual screens on the phone: language, region, Wi-Fi, then any remaining setup prompts.')
        self.label('If a screen differs or supervision is not confirmed, stop and send a screenshot. Do not erase a second time.',12,RED,True)
        self.button('Check the connected phone again',self.find)
    def result(self,r):
        if r.get('removed_lock_test'):
            self.clear();self.title('Test restrictions removed')
            for x in r.get('profiles',[]):self.label(x,10,MUTED)
            self.button('Check the connected phone again',self.find);return
        if r.get('lab'):
            self.clear();self.title('Lab result')
            for x in r.get('notes',[]):self.label(x,10,INK)
            self.copy_button();self.button('Back to lab tests',self.lab,NAVY);self.button('Check the connected phone again',self.find);return
        if r.get('resume12'):
            self.clear();self.title('MDM installed (removable). Removal lock NOT proven')
            for x in r.get('notes',[]):self.label('• '+x,11,INK)
            self.label('Now on the iPhone: Settings > General > VPN & Device Management > KosherGuard profile. Send a picture, including whether Remove Management is there (do not tap it). Also send the restrictions profile page. Then in the dashboard press Lock phone and tell me how many seconds until the phone locks.',11,RED,True)
            self.label('Profiles on phone: '+' | '.join(r.get('profiles',[])),9,MUTED)
            self.copy_button();self.button('Open dashboard',lambda:self.open_url(engine.BASE),BLUE);self.button('Check the connected phone again',self.find);return
        if r.get('fresh'):
            self.clear();self.title('Profile installed. Removal NOT yet proven')
            self.label('The phone was erased, supervised, and the one KosherGuard profile was found on it. Now finish the phone setup screens on the iPhone.',12,RED,True)
            self.label('Server check: '+str(r.get('verify')),11,INK)
            self.label('Then on the iPhone open Settings > General > About (Supervised), then Settings > General > VPN & Device Management > KosherGuard profile. Send me a picture of each, including whether a Remove Management button is there. Do not tap it.')
            self.copy_button();self.button('Open dashboard',lambda:self.open_url(engine.BASE),BLUE);self.button('Check the connected phone again',self.find);return
        if r.get('experiment'):
            self.clear();self.title('Experiment installed: removal NOT verified')
            self.label('One enrollment profile was found after install. This does not prove it is locked, checked in, receiving push commands, or filtering.',12,RED,True)
            if r.get('activation_test'):
                self.label('Now finish the actual Setup Assistant screens manually. Do not restore the old backup. If Remote Management or an error blocks setup, stop and send a screenshot. Do not erase again.',11,RED,True)
            if r.get('backup_dir'):self.label('Backup kept: '+r['backup_dir'],10,MUTED)
            self.label('On the iPhone: Settings > General > VPN & Device Management > profile. Send that screen. If Remove Management exists, tap only far enough to see whether it asks for the special recovery password. Do not enter it or confirm removal. Do not confuse the phone passcode prompt with the profile password.')
            self.button('Check the connected phone again',self.find);return
        self.clear();confirmed=r.get('supervised') is True and r.get('enrolled') is True and r.get('removal_locked') is True
        self.title('Management verified ✓' if confirmed else 'Setup needs attention')
        for k,label in [('supervised','Supervision'),('enrolled','MDM enrollment'),('removal_locked','Enrollment marked non-removable')]:
            v=r.get(k);self.label(label+': '+{True:'confirmed',False:'not confirmed',None:'waiting / unknown'}[v],13,GREEN if v is True else RED,True)
        self.label('Website filter: not verified by this installer.',13,MUTED,True)
        self.label('Management verification is not a test of real filtering or erase-proof protection. Test Settings removal and supported restrictions on the spare phone.')
        if r.get('backup_dir'):self.label('Backup retained on this PC: '+r['backup_dir'],10,MUTED)
        self.button('Open dashboard',lambda:self.open_url(engine.BASE),BLUE);self.button('Set up another phone',self.welcome,NAVY)
    def error(self,err):
        usb.log('Desktop setup stopped',err)
        self.clear();self.title('Setup waiting for verification' if isinstance(err,engine.Pending) else 'Setup stopped')
        self.label('Reason (select and copy from the box, or use the Copy button):',12,RED,True)
        self.select_box(usb._redact(str(err.args[0]) if isinstance(err,usb.SetupError) and err.args else usb.describe_error(err)))
        self.label('Local log: '+str(usb.log_path()),10,MUTED)
        self.label('After erase: press Home, choose language and region, choose Set Up Manually and connect to Wi-Fi. Keep the PC online and USB connected. Stay in Setup Assistant, do not restore the old backup or erase again. Apple Account lock or Remote Management needs owner/organization action.',11,INK)
        self.label('Do not assume the phone is supervised, enrolled, locked or filtered. If it was already erased, keep it connected; do not erase again.')
        self.label('The backup folder is kept. A failed restore may need manual recovery. Send a screenshot before further changes.',11,INK)
        self.copy_button();self.button('Check the connected phone again',self.find);self.button('Open local log folder',self.open_logs,MUTED)
    def open_logs(self):
        if self.preview:return
        p=usb.log_path().parent;p.mkdir(parents=True,exist_ok=True)
        if os.name=='nt':os.startfile(str(p))
    def check_updates(self):
        if self.busy or self.preview:return
        def check():
            try:self.q.put(('update',updater.find_update()))
            except Exception:pass
        threading.Thread(target=check,daemon=True).start()
    def offer_update(self,u):
        if self.busy:return
        if not getattr(sys,'frozen',False):return
        if messagebox.askyesno('KosherGuard update',f"Build {u['number']} is available. Download and verify it, then close this idle app to replace it? Never update during phone setup. You can cancel while it downloads."):
            usb.log(f"update: downloading build {u['number']}")
            self.working('Downloading app update, no phone changes')
            cancel=threading.Event()
            self.update_cancel=cancel
            def stop():
                cancel.set();self.status.config(text='Cancelling the update…')
            self.button('Cancel update and continue without it',stop,MUTED)
            async def get():
                try:
                    p=await asyncio.wait_for(asyncio.to_thread(updater.download,u,requests_session(),cancel),300)
                    return ('ok',p)
                except asyncio.TimeoutError:
                    cancel.set();return ('fail','The update download took more than 5 minutes.')
                except Exception as ex:
                    return ('fail',usb._redact(usb.describe_error(ex)))
            def done(res):
                kind,v=res
                if cancel.is_set():
                    usb.log('update: cancelled or timed out: '+str(v));return self.welcome()
                if kind!='ok':
                    usb.log('update: failed: '+str(v));self.welcome();return messagebox.showinfo('Update skipped','The update did not download ('+str(v)+'). You can keep using this version.')
                try:
                    usb.log('update: replacing app');updater.stage_replace(v);self.root.destroy()
                except Exception as ex:self.error(ex)
            self.submit(get(),done)
    def close(self):
        if self.busy and not messagebox.askyesno('Setup still running','Closing can interrupt setup or restore. Keep the phone connected. Close this window anyway?'):return
        self.root.destroy()

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--preview',action='store_true');p.add_argument('--self-test');p.add_argument('--update-lock-test');a=p.parse_args()
    if a.update_lock_test:
        from pathlib import Path
        Path(a.update_lock_test).write_text(str(os.getpid()))
        time.sleep(3)
    elif a.self_test:
        import json
        from pathlib import Path
        from pymobiledevice3.services.mobile_config import MobileConfigService
        from pymobiledevice3.services.mobilebackup2 import Mobilebackup2Service
        from pymobiledevice3.services.mobile_activation import MobileActivationService
        from pymobiledevice3.lockdown import create_using_usbmux
        from pymobiledevice3.ca import create_keybag_file
        gui=App(preview=True);gui.root.update();gui.info=gui.sample();gui.activation_details();gui.root.update();gui.activation_details(True);gui.root.update();gui.fresh_details();gui.root.update();gui.resume_details();gui.root.update();gui.lab();gui.root.update();gui.clear();gui.select_box('sample error text');gui.label('x');gui.root.update();gui.root.destroy()
        if not os.environ.get('KG_UPDATER_CHILD'):
            updater.test_native_helper()
        Path(a.self_test).write_text(json.dumps({'passed':True,'usb_called':False,'gui':'Tkinter preview initialized','imports':'USB services loaded','native_update_helper':not bool(os.environ.get('KG_UPDATER_CHILD'))}))
    else:App(a.preview).root.mainloop()
