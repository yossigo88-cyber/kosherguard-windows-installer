"""Owner-clicked updater. Downloads only fixed-repository GitHub release assets."""
import hashlib,json,os,subprocess,sys,tempfile
from pathlib import Path
from urllib.parse import urlparse
import requests
REPO='yossigo88-cyber/kosherguard-windows-installer'
BUILD=15
try:
 from build_version import BUILD
except ImportError:pass
class UpdateError(Exception):pass
def allowed(url):
 u=urlparse(url)
 return u.scheme=='https' and u.netloc=='github.com' and u.path.startswith('/'+REPO+'/releases/download/')
def find_update(session=requests):
 r=session.get('https://api.github.com/repos/'+REPO+'/releases',timeout=15);r.raise_for_status();rows=r.json()
 for row in rows:
  tag=row.get('tag_name','')
  if row.get('draft') or not tag.startswith('test-build-'):continue
  try:n=int(tag.removeprefix('test-build-'))
  except ValueError:continue
  if n<=BUILD:continue
  for a in row.get('assets',[]):
   digest=a.get('digest','')
   if a.get('name')=='KosherGuard-Setup.exe' and allowed(a.get('browser_download_url','')) and len(digest)==71 and digest.startswith('sha256:'):
    try:int(digest[7:],16)
    except ValueError:continue
    return {'number':n,'url':a['browser_download_url'],'sha256':digest[7:],'size':a.get('size',0)}
 return None
def download(update,session=requests,cancel=None):
 if not allowed(update.get('url','')):raise UpdateError('Unexpected update address.')
 folder=Path(tempfile.mkdtemp(prefix='KosherGuard-update-'));p=folder/'KosherGuard-Setup.exe'
 h=hashlib.sha256();total=0
 try:
  with session.get(update['url'],stream=True,timeout=60) as r:
   r.raise_for_status()
   with p.open('wb') as f:
    for b in r.iter_content(256*1024):
     if cancel is not None and cancel.is_set():raise UpdateError('Update cancelled.')
     total+=len(b)
     if total>300*1024*1024:raise UpdateError('Update is too large.')
     h.update(b);f.write(b)
  if total!=update['size'] or h.hexdigest()!=update['sha256']:raise UpdateError('Update checksum failed. Existing app was not changed.')
  with p.open('rb') as f:
   if f.read(2)!=b'MZ':raise UpdateError('Update is not a Windows executable.')
  return p
 except Exception:
  p.unlink(missing_ok=True);raise

HELPER = r"""$ErrorActionPreference='Stop'
$c=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'replace.json') -Raw | ConvertFrom-Json
$log=Join-Path $PSScriptRoot 'update-status.txt'
try {
 'Waiting for old app' | Out-File -LiteralPath $log
 try { Wait-Process -Id $c.pid -Timeout 120 -ErrorAction SilentlyContinue } catch {}
 if (Get-Process -Id $c.pid -ErrorAction SilentlyContinue) { throw 'Old app did not close' }
 $copied=$false
 for ($i=0; $i -lt 120; $i++) {
  try {
   Copy-Item -LiteralPath $c.target -Destination $c.backup -Force
   Copy-Item -LiteralPath $c.source -Destination $c.target -Force
   $copied=$true; break
  } catch { Start-Sleep -Seconds 1 }
 }
 if (!$copied) { throw 'App file stayed locked or folder was not writable' }
 'Replaced; launching' | Out-File -LiteralPath $log
 $env:PYINSTALLER_RESET_ENVIRONMENT='1'
 $launch=@{FilePath=$c.target;WorkingDirectory=(Split-Path -Parent $c.target);PassThru=$true}
 if ($c.arguments.Count -gt 0) { $launch.ArgumentList=@($c.arguments) }
 $p=Start-Process @launch
 Start-Sleep -Seconds 4
 if ($p.HasExited -and $p.ExitCode -ne 0) { throw "New app exited with $($p.ExitCode)" }
 'Update launched' | Out-File -LiteralPath $log
} catch {
 $failure=$_
 try { if (Test-Path -LiteralPath $c.backup) { Copy-Item -LiteralPath $c.backup -Destination $c.target -Force } } catch {}
 $failure | Out-File -LiteralPath (Join-Path $PSScriptRoot 'update-error.txt')
 if (!$c.quiet) { Start-Process notepad.exe -ArgumentList ('"'+(Join-Path $PSScriptRoot 'update-error.txt')+'"') }
 exit 1
}
"""
def launch_helper(source,target,pid,arguments=None,quiet=False):
 folder=Path(source).parent
 (folder/'replace.json').write_text(json.dumps({'pid':pid,'target':str(target),'source':str(source),'backup':str(target)+'.previous','arguments':arguments or [],'quiet':quiet}))
 script=folder/'replace.ps1';script.write_text(HELPER)
 env=dict(os.environ);env['PYINSTALLER_RESET_ENVIRONMENT']='1'
 return subprocess.Popen(['powershell.exe','-NoProfile','-ExecutionPolicy','Bypass','-File',str(script)],env=env,creationflags=0x08000000,close_fds=True)

def stage_replace(new_path):
 if os.name!='nt' or not getattr(sys,'frozen',False):raise UpdateError('Automatic replacement requires the Windows executable.')
 return launch_helper(Path(new_path).resolve(),Path(sys.executable).resolve(),os.getpid())

def test_native_helper():
 import shutil,time
 root=Path(tempfile.mkdtemp(prefix='KosherGuard-native-test-'))
 source=root/'download'/'KosherGuard-Setup.exe';source.parent.mkdir();shutil.copy2(sys.executable,source)
 target=root/'installed'/'KosherGuard-Setup.exe';target.parent.mkdir();shutil.copy2(sys.executable,target)
 marker=root/'child-self-test.json'
 # Launch under inherited onefile variables, just as the actual updater does.
 lock_marker=root/'old-pid.txt'
 env=dict(os.environ);env['PYINSTALLER_RESET_ENVIRONMENT']='1'
 sleeper=subprocess.Popen([str(target),'--update-lock-test',str(lock_marker)],env=env)
 until=time.monotonic()+90
 while not lock_marker.exists() and time.monotonic()<until:time.sleep(.1)
 if not lock_marker.exists():raise UpdateError('Old packaged app test did not start')
 inner_pid=int(lock_marker.read_text())
 env_old=os.environ.get('KG_UPDATER_CHILD');os.environ['KG_UPDATER_CHILD']='1'
 try:p=launch_helper(source,target,inner_pid,['--self-test',str(marker)],True)
 finally:
  if env_old is None:os.environ.pop('KG_UPDATER_CHILD',None)
  else:os.environ['KG_UPDATER_CHILD']=env_old
 if p.wait(timeout=120)!=0:raise UpdateError('Native helper failed: '+str(root))
 until=time.monotonic()+90
 while not marker.exists() and time.monotonic()<until:time.sleep(.25)
 if not marker.exists() or json.loads(marker.read_text()).get('passed') is not True:raise UpdateError('Updated packaged child did not finish its self-test: '+str(root))
 if target.read_bytes()!=source.read_bytes() or Path(str(target)+'.previous').read_bytes()!=source.read_bytes():raise UpdateError('Native helper replacement/backup verification failed')
 return True
