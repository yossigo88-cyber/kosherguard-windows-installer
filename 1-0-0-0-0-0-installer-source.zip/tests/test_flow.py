import sys,unittest,asyncio,tempfile,plistlib,sqlite3
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import setup_engine as e,usb_engine as u
class Dev:
 def __init__(self,sup=False):self.sup=sup;self.ops=[]
 async def find(self):self.ops.append('find');return {'serial':'phone1','supervised':self.sup}
 async def backup_to_pc(self,*a,**k):self.ops.append('backup');return {'folder':'/fake/backup'}
 async def erase_and_reconnect(self,*a):self.ops.append('erase');return {'supervised':False}
 async def activate_robust(self,*a):self.ops.append('activate')
 async def connect(self):self.ops.append('connect');return {'supervised':False}
 async def preflight(self):return {'setup_done':False}
 async def activate_and_supervise(self,*a,**k):self.ops.append('supervise')
 async def restore_from_pc(self,*a,**k):self.ops.append('restore')
 async def ensure_supervised(self,*a):self.ops.append('checksup')
class Svc:
 async def approve(self,*a):return {'device_id':'sample','token':'test','secret':'test'}
 async def verify(self,*a):return True
async def install(d,*a):d.ops.append('install')
class Tests(unittest.IsolatedAsyncioTestCase):
 def info(self,sup=False):return {'serial':'phone1','supervised':sup}
 def opts(self):return {'_mock_profile':b'mock','consent':True,'erase':'ERASE','backup_confirmed':True}
 async def run_it(self,d,opts=None,service=None):return await e.run_flow(d,self.info(d.sup),'Name','2125550100',opts or self.opts(),lambda *x:None,lambda i:None,service=service or Svc(),install=install,persist=lambda x:None)
 async def test_order(self):
  d=Dev();r=await self.run_it(d);self.assertEqual(d.ops,['find','backup','find','erase','supervise','restore','checksup','install']);self.assertIsNone(r['filter_active']);self.assertTrue(r['removal_locked'])
 async def test_supervised_no_erase(self):
  d=Dev(True);await self.run_it(d);self.assertEqual(d.ops,['find','install'])
 async def test_consent_required(self):
  for key in ['consent','backup_confirmed','erase']:
   d=Dev();o=self.opts();o[key]=False
   with self.assertRaises(u.SetupError):await self.run_it(d,o)
   self.assertEqual(d.ops,[])
 async def test_unknown_stops(self):
  d=Dev(None)
  with self.assertRaises(u.SetupError):await self.run_it(d)
  self.assertEqual(d.ops,[])
 async def test_bad_contact_stops(self):
  d=Dev()
  with self.assertRaises(u.SetupError):await e.run_flow(d,self.info(),'','bad',self.opts(),lambda*x:None,lambda*x:None)
  self.assertEqual(d.ops,[])
 async def test_changed_phone_stops(self):
  d=Dev()
  async def changed():return {'serial':'other','supervised':False}
  d.find=changed
  with self.assertRaises(u.SetupError):await self.run_it(d)
  self.assertEqual(d.ops,[])
 async def test_backup_failure_no_erase(self):
  d=Dev()
  async def fail(*a,**k):raise u.BackupError('bad backup')
  d.backup_to_pc=fail
  with self.assertRaises(u.BackupError):await self.run_it(d)
  self.assertEqual(d.ops,['find'])
 async def test_approval_failure_no_phone_changes(self):
  class Bad(Svc):
   async def approve(self,*a):raise e.Pending('waiting')
  d=Dev()
  with self.assertRaises(e.Pending):await self.run_it(d,service=Bad())
  self.assertEqual(d.ops,[])
 async def test_pending_not_success(self):
  class Bad(Svc):
   async def verify(self,*a):raise e.Pending('not yet')
  with self.assertRaises(e.Pending):await self.run_it(Dev(True),service=Bad())
 async def test_resume_requires_setup_screen(self):
  d=Dev();o=self.opts();o.update(resume=True,backup_dir='/backup')
  with self.assertRaises(u.SetupError):await self.run_it(d,o)
  self.assertEqual(d.ops,[])
 async def test_resume_no_second_erase(self):
  d=Dev();o=self.opts();o.update(resume=True,backup_dir='/backup');i=self.info();i['pf']={'setup_done':False}
  with patch.object(u,'verify_backup',return_value={}):await e.run_flow(d,i,'Name','2125550100',o,lambda*x:None,lambda*x:None,service=Svc(),install=install,persist=lambda x:None)
  self.assertNotIn('erase',d.ops);self.assertNotIn('backup',d.ops)
 async def test_verify_false_not_success(self):
  class Reply(e.Service):
   def call(self,*a):return {'status':'failed'}
  with self.assertRaises(u.SetupError):await Reply().verify({'token':'t','secret':'s'},lambda*x:None)
 async def test_no_third_party_or_secrets(self):
  src=(Path(__file__).parents[1]/'setup_engine.py').read_text()
  self.assertNotIn('manageengine',src.lower());self.assertNotIn('Challenge',src)
 async def test_no_preview_live_actions(self):
  import ast
  ast.parse((Path(__file__).parents[1]/'app.py').read_text())
  self.assertIsNotNone(e.load_state())
 async def test_swap_during_backup_blocks_erase(self):
  d=Dev();calls=[]
  async def change():
   calls.append(1)
   return {'serial':'phone1' if len(calls)==1 else 'other','supervised':False}
  d.find=change
  with self.assertRaises(u.SetupError):await self.run_it(d)
  self.assertEqual(d.ops,['backup'])
 async def test_manifest_filter_fixture(self):
  import shutil
  with tempfile.TemporaryDirectory() as td:
   root=Path(td);dd=root/'phone1';dd.mkdir()
   for n,j in [('Info.plist',{'Device Name':'sample'}),('Manifest.plist',{'IsEncrypted':False}),('Status.plist',{'SnapshotState':'finished'})]: (dd/n).write_bytes(plistlib.dumps(j))
   c=sqlite3.connect(dd/'Manifest.db');c.execute('CREATE TABLE Files(fileID TEXT,domain TEXT,relativePath TEXT,flags INT)')
   rows=[('aa001','HomeDomain','Library/file.txt',1),('bb002','ManagedPreferencesDomain','test.plist',1)]
   c.executemany('INSERT INTO Files VALUES(?,?,?,?)',rows);c.commit();c.close()
   for fid,*_ in rows:(dd/fid[:2]).mkdir(exist_ok=True);(dd/fid[:2]/fid).write_text('test')
   v=u.verify_backup(root,'phone1');self.assertEqual(v['missing'],0)
   original=(dd/'Manifest.db').read_bytes();stats=u.filter_backup_for_restore(root,'phone1')
   self.assertEqual(stats['removed'],1);self.assertEqual((dd/u.FULL_MANIFEST).read_bytes(),original)
   shutil.copy2(dd/u.FULL_MANIFEST,dd/'Manifest.db');self.assertEqual((dd/'Manifest.db').read_bytes(),original)
   (dd/'aa'/'aa001').unlink()
   with self.assertRaises(u.BackupError):u.verify_backup(root,'phone1')
 async def test_profile_rejects_unexpected_host(self):
  import io,zipfile
  p={'PayloadIdentifier':e.IDENT,'PayloadRemovalDisallowed':True,'PayloadContent':[{'PayloadType':'com.apple.mdm','ServerURL':'https://wrong.invalid/mdm','CheckInURL':'https://mdm.kosherguard.xyz/checkin'}]}
  b=io.BytesIO()
  with zipfile.ZipFile(b,'w') as z:z.writestr('MDM-Windows-Installer/enroll.mobileconfig',plistlib.dumps(p))
  class Reply:ok=True;content=b.getvalue()
  with patch.object(e.requests,'get',return_value=Reply()):
   with self.assertRaises(u.SetupError):e.bundled_profile()
 async def test_enroll_checks_identity_and_lock(self):
  import types
  state={'match':True,'readback':True,'installed':False,'listed':True}
  class MC:
   def __init__(self,*a):pass
   async def __aenter__(self):return self
   async def __aexit__(self,*a):pass
   async def get_cloud_configuration(self):return {'IsSupervised':True,'IsMDMUnremovable':state['readback']}
   async def set_cloud_configuration(self,*a):raise AssertionError('Enrollment must not rewrite applied cloud config')
   async def install_profile_silent(self,*a):state['installed']=True
   async def get_profile_list(self):return {'ProfileMetadata':{e.IDENT:{}} if state['listed'] else {}}
  class D:
   client=None
   async def _is_supervised(self):return True
  fake=types.ModuleType('pymobiledevice3.services.mobile_config');fake.MobileConfigService=MC
  with patch.dict(sys.modules,{'pymobiledevice3.services.mobile_config':fake}),patch.object(u,'get_identity',return_value=Path('mock')),patch.object(u,'_cert_matches',side_effect=lambda *x:state['match']):
   state['match']=False
   with self.assertRaises(u.SetupError):await e.enroll(D(),b'mock',lambda*x:None)
   self.assertFalse(state['installed']);state['match']=True;state['readback']=False
   await e.enroll(D(),b'mock',lambda*x:None)
   self.assertTrue(state['installed']);state['readback']=True;state['listed']=False
   with self.assertRaises(e.Pending):await e.enroll(D(),b'mock',lambda*x:None)
   state['listed']=True;await e.enroll(D(),b'mock',lambda*x:None)
 async def test_foreign_clean_start_requires_exact_owner_phrase(self):
  d=Dev(True);o=self.opts();o.update(transfer=True)
  with self.assertRaises(u.SetupError):await self.run_it(d,o)
  self.assertEqual(d.ops,[])
 async def test_foreign_clean_start_erases_supervises_no_old_restore(self):
  d=Dev(True);o=self.opts();o.update(transfer=True,owner_phrase='OWN SPARE ERASE')
  await self.run_it(d,o)
  self.assertEqual(d.ops,['find','backup','find','erase','activate','connect','supervise','install'])
 async def test_clean_start_refused_on_unknown_and_resume(self):
  for sup,resume in [(None,False),(False,False),(True,True)]:
   d=Dev(sup);o=self.opts();o.update(transfer=True,owner_phrase='OWN SPARE ERASE',resume=resume)
   with self.assertRaises(u.SetupError):await self.run_it(d,o)
   self.assertEqual(d.ops,[])

 async def test_old_supervision_remaining_stops_without_install(self):
  d=Dev(True);o=self.opts();o.update(transfer=True,owner_phrase='OWN SPARE ERASE')
  async def bad(*a):d.ops.append('erase');return {'supervised':True}
  async def old():return {'supervised':True}
  d.connect=old
  d.erase_and_reconnect=bad
  with self.assertRaises(u.SetupError):await self.run_it(d,o)
  self.assertNotIn('install',d.ops);self.assertNotIn('supervise',d.ops)

 async def test_updater_rejects_wrong_repo_and_hash(self):
  import updater
  self.assertFalse(updater.allowed('https://evil.invalid/test.exe'))
  self.assertFalse(updater.allowed('https://github.com/other/repo/releases/download/v/app.exe'))
  class R:
   def raise_for_status(self):pass
   def __enter__(self):return self
   def __exit__(self,*a):pass
   def iter_content(self,*a):return [b'MZbad']
  class S:
   def get(self,*a,**k):return R()
  with self.assertRaises(updater.UpdateError):updater.download({'url':'https://github.com/'+updater.REPO+'/releases/download/test-build-9/KosherGuard-Setup.exe','size':5,'sha256':'0'*64},S())
 async def test_updater_selects_only_newer_verified_asset(self):
  import updater
  class R:
   def raise_for_status(self):pass
   def json(self):return [{'tag_name':'test-build-99','assets':[{'name':'KosherGuard-Setup.exe','browser_download_url':'https://github.com/'+updater.REPO+'/releases/download/test-build-99/KosherGuard-Setup.exe','digest':'sha256:'+'a'*64,'size':100}]}]
  class S:
   def get(self,*a,**k):return R()
  self.assertEqual(updater.find_update(S())['number'],99)

 async def test_continue_clean_unknown_activates_never_erases(self):
  d=Dev(None);i=self.info(None);i.update(activated=False,pf={'setup_done':False})
  saved={'udid':'phone1','phase':'erased','clean_start':True,'backup_dir':'/old'}
  o=self.opts();o.update(continue_clean=True,continue_phrase='CONTINUE WITHOUT ERASE')
  with patch.object(e,'load_state',return_value=saved):
   await e.run_flow(d,i,'Name','2125550100',o,lambda*x:None,lambda*x:None,service=Svc(),install=install,persist=lambda x:None)
  self.assertEqual(d.ops,['find','find','activate','connect','supervise','install'])
 async def test_continue_guard_rejects_uncertain_or_other_phone(self):
  i={'serial':'phone1','activated':False}
  saved={'udid':'phone1','phase':'erased','clean_start':True}
  self.assertTrue(e.can_continue_clean(i,saved))
  for change in [{'phase':'erase_requested'},{'udid':'other'},{'clean_start':False}]:
   self.assertFalse(e.can_continue_clean(i,dict(saved,**change)))
  self.assertFalse(e.can_continue_clean(dict(i,activated=True),saved))
 async def test_continue_clean_old_or_unknown_after_activation_stops(self):
  for sup in [True,None]:
   d=Dev(None)
   async def current():return {'supervised':sup}
   d.connect=current
   with self.assertRaises(u.SetupError):await e.confirm_clean_after_activation(d,lambda*x:None)
   self.assertNotIn('supervise',d.ops);self.assertNotIn('install',d.ops)

 async def test_empty_error_has_visible_type(self):
  self.assertIn('TimeoutError',u.describe_error(TimeoutError()))
  self.assertTrue(u.error_detail(TimeoutError()).strip())
