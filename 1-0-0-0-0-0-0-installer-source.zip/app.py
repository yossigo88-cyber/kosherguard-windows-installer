"""KosherGuard desktop setup. Preview mode never imports USB libraries or calls services."""
import argparse, asyncio, queue, threading, time, os, sys
import tkinter as tk
from tkinter import ttk, messagebox
import updater
import setup_engine as engine
import usb_engine as usb
DARK='#102341'; NAVY='#142f59'; BLUE='#2475cf'; LIGHT='#eef5fe'; WHITE='#ffffff'; INK='#203047'; MUTED='#63758b'; RED='#b92832'; GREEN='#187752'

class App:
    def __init__(self, preview=False):
        self.preview=preview; self.busy=False; self.q=queue.Queue(); self.info=None;self.dev=None;self.options={};self.started=None
        self.root=tk.Tk();self.root.title('KosherGuard PC Setup');self.root.geometry('760x820');self.root.minsize(640,560);self.root.configure(bg=WHITE)
        self.root.protocol('WM_DELETE_WINDOW',self.close)
        self.loop=asyncio.new_event_loop();threading.Thread(target=self.loop.run_forever,daemon=True).start()
        h=tk.Frame(self.root,bg=DARK,padx=28,pady=17);h.pack(fill='x')
        tk.Label(h,text='✦',font=('Segoe UI',22,'bold'),fg='#6db9ff',bg=DARK).pack(side='left')
        tk.Label(h,text='  KosherGuard',font=('Segoe UI',20,'bold'),fg=WHITE,bg=DARK).pack(side='left')
        tk.Label(h,text='PC SETUP',font=('Segoe UI',10,'bold'),fg='#b9d2f1',bg=DARK).pack(side='right')
        footer='PREVIEW ONLY • Sample phone • No USB or network' if preview else 'Free • Local USB setup • Spare-phone test build • Owner consent required'
        tk.Label(self.root,text=footer,font=('Segoe UI',9),bg=LIGHT,fg=MUTED,pady=12).pack(side='bottom',fill='x')
        w=tk.Frame(self.root,bg=WHITE);w.pack(fill='both',expand=True)
        self.canvas=tk.Canvas(w,bg=WHITE,highlightthickness=0);sb=tk.Scrollbar(w,command=self.canvas.yview);sb.pack(side='right',fill='y');self.canvas.pack(side='left',fill='both',expand=True);self.canvas.configure(yscrollcommand=sb.set)
        self.content=tk.Frame(self.canvas,bg=WHITE,padx=38,pady=24);win=self.canvas.create_window(0,0,window=self.content,anchor='nw')
        self.content.bind('<Configure>',lambda e:self.canvas.configure(scrollregion=self.canvas.bbox('all')))
        self.canvas.bind('<Configure>',lambda e:self.canvas.itemconfigure(win,width=e.width))
        self.root.bind_all('<MouseWheel>',lambda e:self.canvas.yview_scroll(-1 if e.delta>0 else 1,'units'))
        st=ttk.Style(self.root);st.theme_use('clam');st.configure('KG.Horizontal.TProgressbar',background=BLUE,troughcolor=LIGHT)
        self.root.after(100,self.pump);self.welcome()
        if not preview:self.root.after(1500,self.check_updates)
    def clear(self):
        for w in self.content.winfo_children():w.destroy()
        self.canvas.yview_moveto(0)
    def label(self,text,size=12,color=INK,bold=False):
        x=tk.Label(self.content,text=text,font=('Segoe UI',size,'bold' if bold else 'normal'),bg=WHITE,fg=color,wraplength=620,justify='left',anchor='w');x.pack(fill='x',pady=(0,12));return x
    def title(self,text):return self.label(text,22,DARK,True)
    def button(self,text,fn,color=BLUE):
        b=tk.Button(self.content,text=text,command=fn,bg=color,fg=WHITE,activebackground=NAVY,activeforeground=WHITE,font=('Segoe UI',12,'bold'),relief='flat',padx=20,pady=12,wraplength=580,justify='left',cursor='hand2');b.pack(anchor='w',pady=(7,7));return b
    def entry(self,text,show=None,value=''):
        self.label(text,10,INK,True);e=tk.Entry(self.content,font=('Segoe UI',12),show=show,relief='solid',bd=1);e.pack(fill='x',ipady=7,pady=(0,13));e.insert(0,value);return e
    def check(self,text,var):
        tk.Checkbutton(self.content,text=text,variable=var,font=('Segoe UI',11),bg=WHITE,fg=INK,wraplength=605,justify='left',anchor='w').pack(fill='x',pady=(2,9))
    def submit(self,coro,done):
        if self.busy:return
        self.busy=True
        f=asyncio.run_coroutine_threadsafe(coro,self.loop)
        def complete(f):
            try:self.q.put(('done',(done,f.result())))
            except Exception as e:self.q.put(('error',e))
        f.add_done_callback(complete)
    def pump(self):
        try:
            while True:
                kind,v=self.q.get_nowait()
                if kind=='done':self.busy=False;v[0](v[1])
                elif kind=='error':self.busy=False;self.error(v)
                elif kind=='update':
                    if not self.busy and v:self.offer_update(v)
                elif kind=='progress':
                    text,pct=v
                    if hasattr(self,'status') and self.status.winfo_exists():self.status.config(text=text)
                    if pct is not None and hasattr(self,'bar') and self.bar.winfo_exists():self.bar.stop();self.bar.config(mode='determinate',value=pct)
                elif kind=='step':
                    if hasattr(self,'step_label') and self.step_label.winfo_exists():self.step_label.config(text='\n'.join(('✓ ' if i<v else '➜ ' if i==v else '    ')+x for i,x in enumerate(engine.STEPS)))
        except queue.Empty:pass
        self.root.after(100,self.pump)
    def progress(self,text,pct=None):self.q.put(('progress',(text,pct)))
    def welcome(self):
        self.clear();self.title('Set up a protected iPhone')
        self.label('Connect ONE iPhone to this Windows PC with a USB cable. Unlock it and tap "Trust This Computer" if asked.')
        self.label('First hardware test: use a spare phone and keep a separate, usable backup. First-time supervision erases the phone.',12,RED,True)
        self.label('Our own KosherGuard MDM. No Apple Business enrollment or third-party MDM. No phone changes happen during discovery.')
        self.button('Find my iPhone  →',self.find)
        self.button('Open KosherGuard dashboard',lambda:self.open_url(engine.BASE),NAVY)
        self.label('Apple Devices from Microsoft Store supplies the USB driver. A data-capable cable is required.',10,MUTED)
    def open_url(self,url):
        if not self.preview:
            import webbrowser;webbrowser.open(url)
    def sample(self):return {'name':'Spare iPhone','model':'iPhone 8','ios':'16.7','serial':'SAMPLE-ONLY','supervised':False,'activated':True,'pf':{'space_msg':'Sample: 100 GB free on this PC.','encrypted':False}}
    def find(self):
        if self.preview:self.info=self.sample();return self.found(self.info)
        self.working('Checking the USB connection…')
        async def job():
            if self.dev:await self.dev.close()
            self.dev=usb.RealDevice();i=await self.dev.find();i['pf']=await self.dev.preflight();return i
        self.submit(job(),self.found)
    def found(self,info):
        self.info=info;self.clear();self.title('Your iPhone is connected')
        self.label(f"{info['name']}  ·  {info['model']}  ·  iOS {info['ios']}",15,DARK,True)
        sup=info.get('supervised');self.label('Supervised: '+{True:'Yes',False:'No',None:'could not confirm'}[sup],13,DARK,True)
        self.label('Customer details will be linked to this detected phone after you approve it in your dashboard.')
        self.label(info.get('pf',{}).get('space_msg',''),11,MUTED)
        saved=engine.load_state() if not self.preview else {}
        if engine.can_continue_clean(info,saved):
            self.label('This PC recorded the clean-start erase for this same phone. Continue activation and verification only. No second erase and no old backup restore.',11,RED,True)
            self.button('Continue clean start (NO ERASE)',lambda:self.details(continue_clean=True),GREEN)
        if engine.can_continue_clean(info,saved):
            pass
        elif sup is None:
            self.label('Supervision is unknown. Setup is stopped. No erase or install is offered.',12,RED,True)
        else:
            self.button('Enroll this iPhone (no erase)' if sup else 'Set up this iPhone (erases)',self.details,GREEN)
            if sup is True:self.button('My OWN spare phone: clean start (ERASES)',lambda:self.details(transfer=True),RED)
            saved=engine.load_state() if not self.preview else {}
            if saved.get('udid')==info['serial'] and saved.get('phase') in ('erase_requested','erased','supervised','restored'):
                if saved.get('backup_dir') and not saved.get('clean_start'):self.button('Resume interrupted setup (no second erase)',lambda:self.details(saved),NAVY)
        if sup is True and saved.get('udid')==info.get('serial') and saved.get('clean_start'):
            self.button('EXPERIMENT: one profile + removal password (no erase)',lambda:self.details(password_test=True),NAVY)
        self.button('Check the connected phone again',self.find,MUTED)
    def details(self,resume=None,transfer=False,continue_clean=False,password_test=False):
        self.password_test=password_test
        self.continue_clean=continue_clean
        self.transfer=transfer
        self.resume=resume if isinstance(resume,dict) else None;self.clear();self.title('Clean start: OWN spare phone only' if transfer else 'Set up this iPhone' if not self.resume else 'Resume without erasing')
        self.label('1. Customer details',13,DARK,True)
        self.name=self.entry('Customer name',value='Sample Customer' if self.preview else '')
        self.phone=self.entry('Customer phone number',value='2125550100' if self.preview else '')
        self.label('2. Your data',13,DARK,True)
        self.backup=tk.BooleanVar(value=True)
        if password_test:
            self.label('EXPERIMENT on your own spare only. iOS may reject this MDM + removal-password combination. No erase and no removable fallback. If accepted, a Remove button may remain. This is not a proven non-removable enrollment or dashboard-only removal. Save your recovery password privately.',11,RED,True)
            self.test_password=self.entry('Recovery password (12+ characters, keep privately)',show='*')
            self.test_phrase=self.entry('Type TEST ONE PROFILE to allow this experiment')
        elif continue_clean:
            self.label('On iPhone: press Home, choose language/region, Set Up Manually, then join Wi-Fi. Stay in Setup Assistant; do not restore a backup or finish to Home. Keep this PC online. Continue Apple activation, then verify old supervision is gone before fresh supervision. No erase, backup restore, or bypass is performed.',11,RED,True)
            self.continue_phrase=self.entry('At Hello/Setup Assistant: type CONTINUE WITHOUT ERASE')
        elif transfer:
            self.check('Keep a local safety backup (NOT restored automatically)',self.backup)
            self.label('This erases the old supervision and ALL phone data if iOS allows it. An old supervised backup can bring the old setup back, so this path starts fresh. Apple Account activation and any organization release are still required. This is not a bypass.',11,RED)
        elif self.info.get('supervised') is False and not self.resume:
            self.check('Make and restore a local PC backup before enrollment',self.backup)
            self.label('Restore leaves out management and selected system settings to preserve supervision. Apps may download again. This is not an identical copy of everything.',10,MUTED)
        elif self.resume:
            self.label('Uses the saved backup. No second erase will be sent.',11,MUTED)
        else:
            self.label('Already supervised: enrollment only. No backup, erase or restore.',11,MUTED)
        self.password=None
        if self.info.get('pf',{}).get('encrypted') or self.resume:
            self.password=self.entry('Encrypted backup password, if required (stays on this PC)',show='•')
        self.needs_erase=not password_test and not continue_clean and not self.resume and (self.info.get('supervised') is False or transfer)
        if self.needs_erase:
            self.label('3. Stop: this erases the iPhone',15,RED,True)
            self.consent=tk.BooleanVar(value=False);self.independent=tk.BooleanVar(value=False)
            self.check('Find My is OFF, and the phone owner agrees to erasing this phone.',self.consent)
            self.check('I saved what I need elsewhere and accept losing ALL phone data.' if transfer else 'I have a separate backup I know can be restored.',self.independent)
            self.erase=self.entry('Type ERASE to allow erasing after backup checks')
            if transfer:self.owner_phrase=self.entry('Type OWN SPARE ERASE to confirm this is your own spare phone')
        self.button('Start  →',self.start,GREEN);self.button('Back',lambda:self.found(self.info),MUTED)
    def start(self):
        if self.preview:return self.working('Preview: preparing setup')
        if self.busy:return
        if self.needs_erase and not (self.consent.get() and self.independent.get() and self.erase.get()=='ERASE'):
            return messagebox.showwarning('Before erasing','Tick both consent boxes and type ERASE exactly. Nothing was changed.')
        opts={'backup':self.backup.get(),'password':self.password.get() if self.password else '', 'consent':not self.needs_erase or self.consent.get(),'backup_confirmed':not self.needs_erase or self.independent.get(),'erase':self.erase.get() if self.needs_erase else '', 'resume':bool(self.resume)}
        if self.resume:opts.update(backup_dir=self.resume.get('backup_dir'),restore_done=self.resume.get('restore_done',False))
        if self.transfer:opts.update(transfer=True,owner_phrase=self.owner_phrase.get())
        if self.password_test:opts.update(password_test=True,test_password=self.test_password.get(),test_phrase=self.test_phrase.get())
        if self.continue_clean:opts.update(continue_clean=True,continue_phrase=self.continue_phrase.get())
        name,phone=self.name.get(),self.phone.get();self.working('Approve setup in your dashboard')
        self.submit(engine.run_flow(self.dev,self.info,name,phone,opts,self.progress,lambda i:self.q.put(('step',i))),self.result)
    def working(self,title='Setting up your iPhone…'):
        self.clear();self.title(title)
        self.label('Keep the cable connected. Watch for Trust, unlock or setup prompts on the phone.',11,INK)
        self.step_label=self.label('\n'.join('    '+s for s in engine.STEPS),12,MUTED)
        self.bar=ttk.Progressbar(self.content,mode='indeterminate',style='KG.Horizontal.TProgressbar');self.bar.pack(fill='x',pady=14);self.bar.start(15)
        self.status=self.label('Waiting for the next confirmed step…',12,INK)
        self.elapsed=self.label('',10,MUTED);self.started=time.monotonic();self.tick()
        self.label('No "locked" or "filter active" claim until the relevant device check succeeds.',10,MUTED)
    def tick(self):
        if hasattr(self,'elapsed') and self.elapsed.winfo_exists():
            n=int(time.monotonic()-self.started);self.elapsed.config(text=f'App is working  ·  {n//60:02}:{n%60:02} elapsed');self.root.after(1000,self.tick)
    def phone_wait(self):
        self.clear();self.title('Finish setup on the iPhone')
        self.label('Keep USB connected. Follow the actual screens on the phone: language, region, Wi-Fi, then any remaining setup prompts.')
        self.label('If a screen differs or supervision is not confirmed, stop and send a screenshot. Do not erase a second time.',12,RED,True)
        self.button('Check the connected phone again',self.find)
    def result(self,r):
        if r.get('experiment'):
            self.clear();self.title('Experiment installed: removal NOT verified')
            self.label('One enrollment profile was found after install. This does not prove it is locked, checked in, or filtering.',12,RED,True)
            self.label('On the iPhone: Settings > General > VPN & Device Management > profile. Send that screen. If Remove Management exists, tap only far enough to see whether it asks for the special recovery password. Do not enter it or confirm removal. Do not confuse the phone passcode prompt with the profile password.')
            self.button('Check the connected phone again',self.find);return
        self.clear();confirmed=r.get('supervised') is True and r.get('enrolled') is True and r.get('removal_locked') is True
        self.title('Management verified ✓' if confirmed else 'Setup needs attention')
        for k,label in [('supervised','Supervision'),('enrolled','MDM enrollment'),('removal_locked','Enrollment marked non-removable')]:
            v=r.get(k);self.label(label+': '+{True:'confirmed',False:'not confirmed',None:'waiting / unknown'}[v],13,GREEN if v is True else RED,True)
        self.label('Website filter: not verified by this installer.',13,MUTED,True)
        self.label('Management verification is not a test of real filtering or erase-proof protection. Test Settings removal and supported restrictions on the spare phone.')
        if r.get('backup_dir'):self.label('Backup retained on this PC: '+r['backup_dir'],10,MUTED)
        self.button('Open dashboard',lambda:self.open_url(engine.BASE),BLUE);self.button('Set up another phone',self.welcome,NAVY)
    def error(self,err):
        usb.log('Desktop setup stopped',err)
        self.clear();self.title('Setup waiting for verification' if isinstance(err,engine.Pending) else 'Setup stopped')
        self.label('Reason: '+usb._redact(usb.describe_error(err)),12,RED,True)
        self.label('Local log: '+str(usb.log_path()),10,MUTED)
        self.label('After erase: press Home, choose language and region, choose Set Up Manually and connect to Wi-Fi. Keep the PC online and USB connected. Stay in Setup Assistant, do not restore the old backup or erase again. Apple Account lock or Remote Management needs owner/organization action.',11,INK)
        self.label('Do not assume the phone is supervised, enrolled, locked or filtered. If it was already erased, keep it connected; do not erase again.')
        self.label('The backup folder is kept. A failed restore may need manual recovery. Send a screenshot before further changes.',11,INK)
        self.button('Check the connected phone again',self.find);self.button('Open local log folder',self.open_logs,MUTED)
    def open_logs(self):
        if self.preview:return
        p=usb.log_path().parent;p.mkdir(parents=True,exist_ok=True)
        if os.name=='nt':os.startfile(str(p))
    def check_updates(self):
        if self.busy or self.preview:return
        def check():
            try:self.q.put(('update',updater.find_update()))
            except Exception:pass
        threading.Thread(target=check,daemon=True).start()
    def offer_update(self,u):
        if self.busy:return
        if not getattr(sys,'frozen',False):return
        if messagebox.askyesno('KosherGuard update',f"Build {u['number']} is available. Download and verify it, then close this idle app to replace it? Never update during phone setup."):
            self.working('Downloading app update, no phone changes')
            async def get():return await asyncio.to_thread(updater.download,u)
            def done(path):
                try:
                    updater.stage_replace(path);self.root.destroy()
                except Exception as ex:self.error(ex)
            self.submit(get(),done)
    def close(self):
        if self.busy and not messagebox.askyesno('Setup still running','Closing can interrupt setup or restore. Keep the phone connected. Close this window anyway?'):return
        self.root.destroy()

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--preview',action='store_true');p.add_argument('--self-test');p.add_argument('--update-lock-test');a=p.parse_args()
    if a.update_lock_test:
        from pathlib import Path
        Path(a.update_lock_test).write_text(str(os.getpid()))
        time.sleep(3)
    elif a.self_test:
        import json
        from pathlib import Path
        from pymobiledevice3.services.mobile_config import MobileConfigService
        from pymobiledevice3.services.mobilebackup2 import Mobilebackup2Service
        from pymobiledevice3.services.mobile_activation import MobileActivationService
        from pymobiledevice3.lockdown import create_using_usbmux
        from pymobiledevice3.ca import create_keybag_file
        gui=App(preview=True);gui.root.update();gui.info=gui.sample();gui.details();gui.root.update();gui.root.destroy()
        if not os.environ.get('KG_UPDATER_CHILD'):
            updater.test_native_helper()
        Path(a.self_test).write_text(json.dumps({'passed':True,'usb_called':False,'gui':'Tkinter preview initialized','imports':'USB services loaded','native_update_helper':not bool(os.environ.get('KG_UPDATER_CHILD'))}))
    else:App(a.preview).root.mainloop()
