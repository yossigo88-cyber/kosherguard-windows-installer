"""Own-MDM setup, called only after explicit GUI approval. No work runs on import."""
import asyncio, json, os, plistlib, webbrowser
from pathlib import Path
import requests
import usb_engine as usb

BASE = 'https://admin.kosherguard.xyz'
IDENT = 'com.mdm.enroll'
STEPS = ['Check setup approval', 'Get ready', 'Erase the phone', 'Supervise', 'Prepare profile', 'Install KosherGuard profile', 'Check in with server']

class Pending(usb.SetupError): pass

def bundled_profile(removable=False):
    # Fetch the currently shipped enrollment profile, never bundle its live SCEP challenge.
    import io, zipfile
    r=requests.get(BASE+'/d/daac78f0c49a7ccfecd797a4ef1cebfb/MDM-Windows-Installer.zip',timeout=30,allow_redirects=False)
    if not r.ok or len(r.content)>2000000: raise usb.SetupError('Could not read the current enrollment package. Nothing was erased.')
    with zipfile.ZipFile(io.BytesIO(r.content)) as z:
        data=z.read('MDM-Windows-Installer/enroll.mobileconfig')
    p = plistlib.loads(data)
    kinds = {x.get('PayloadType'): x for x in p.get('PayloadContent', [])}
    mdm = kinds.get('com.apple.mdm', {})
    if p.get('PayloadIdentifier') != IDENT or p.get('PayloadRemovalDisallowed') is not True:
        raise usb.SetupError('Enrollment profile is not the expected locked KosherGuard profile.')
    if mdm.get('ServerURL') != 'https://mdm.kosherguard.xyz/mdm' or mdm.get('CheckInURL') != 'https://mdm.kosherguard.xyz/checkin':
        raise usb.SetupError('Enrollment profile points to an unexpected management service.')
    if kinds.get('com.apple.security.scep',{}).get('PayloadContent',{}).get('URL') != 'https://mdm.kosherguard.xyz/scep':
        raise usb.SetupError('Enrollment profile is missing the device identity payload.')
    if removable:
        p.pop('PayloadRemovalDisallowed',None); p['PayloadRemovalDisallowed']=False
        return plistlib.dumps(p)
    return data

def state_path():
    return usb.identity_path().parent / 'desktop-session.json'

def save_state(data):
    p = state_path(); p.parent.mkdir(parents=True, exist_ok=True)
    # No approval token, poll secret, backup password or key material is persisted here.
    p.write_text(json.dumps(data, indent=2));
    if os.name != 'nt': p.chmod(0o600)

def load_state():
    try: return json.loads(state_path().read_text())
    except (OSError, ValueError): return {}

class Service:
    def __init__(self, session=None): self.session = session or requests.Session()
    def call(self, path, data=None, secret=None):
        headers = {'X-Setup-Secret': secret} if secret else {}
        r = self.session.request('POST' if data is not None else 'GET', BASE+path, json=data, headers=headers, timeout=25, allow_redirects=False)
        if not r.ok: raise usb.SetupError('KosherGuard setup request failed (HTTP %d). No new erase will be started. Open the dashboard and retry.' % r.status_code)
        j = r.json()
        if not isinstance(j, dict): raise usb.SetupError('KosherGuard returned an unexpected reply.')
        return j
    async def approve(self, info, name, phone, progress):
        j = await asyncio.to_thread(self.call, '/api/setup/start', {'udid':info['serial'], 'name':name, 'phone':phone})
        token, secret, url = j['token'], j['pollSecret'], j['approvalUrl']
        from urllib.parse import urlparse
        u=urlparse(url)
        if u.scheme!='https' or u.netloc!='admin.kosherguard.xyz': raise usb.SetupError('Unexpected dashboard approval address.')
        usb.add_secret(token); usb.add_secret(secret); usb.add_secret(url)
        webbrowser.open(url)
        progress('Approve this detected phone in the dashboard. Setup has not erased anything.')
        for _ in range(300):
            r=await asyncio.to_thread(self.call, '/api/setup/'+token+'/poll', None, secret)
            if r.get('status')=='approved': return {'token':token,'secret':secret,'device_id':r.get('deviceId')}
            if r.get('status') in ('denied','expired'): raise usb.SetupError('Dashboard approval was declined or expired. Nothing was erased.')
            await asyncio.sleep(3)
        raise Pending('Dashboard approval timed out. No erase was started.')
    async def verify(self, grant, progress):
        for _ in range(60):
            r=await asyncio.to_thread(self.call, '/api/setup/'+grant['token']+'/verify', {}, grant['secret'])
            if r.get('status')=='verified': return True
            if r.get('status')=='failed': raise usb.SetupError('Enrollment was not confirmed as non-removable. Do not assume management is locked.')
            progress('Waiting for the phone to check in and confirm its enrollment profile.')
            await asyncio.sleep(3)
        raise Pending('Management verification is still pending. The profile may be installed. Check the dashboard before retrying; do not erase again.')

async def identity_matches(dev):
    if not usb.identity_path().exists(): return False
    from pymobiledevice3.services.mobile_config import MobileConfigService
    async with MobileConfigService(dev.client) as mc:
        cfg=await mc.get_cloud_configuration()
    return usb._cert_matches(cfg,usb.identity_path()) is True

def password_test_profile(data,password):
    if len(password)<12: raise usb.SetupError('Use a recovery password of at least 12 characters. Keep it privately; never send it in chat.')
    p=plistlib.loads(data)
    if p.get('PayloadIdentifier')!=IDENT or p.get('PayloadRemovalDisallowed') is not True:
        raise usb.SetupError('Expected locked enrollment profile required. No removable fallback.')
    kinds=[x.get('PayloadType') for x in p.get('PayloadContent',[])]
    if 'com.apple.mdm' not in kinds or 'com.apple.profileRemovalPassword' in kinds:
        raise usb.SetupError('Unexpected profile payload combination.')
    from uuid import uuid4
    p['PayloadContent'].append({'PayloadType':'com.apple.profileRemovalPassword','PayloadIdentifier':IDENT+'.removal-test','PayloadUUID':str(uuid4()),'PayloadVersion':1,'RemovalPassword':password})
    return plistlib.dumps(p)

async def run_password_test(dev,info,name,phone,options,progress,step,service=None):
    if not name.strip() or not 7 <= len(''.join(c for c in phone if c.isdigit())) <= 15:
        raise usb.SetupError('Enter a customer name and phone number.')
    saved=load_state()
    if saved.get('udid')!=info.get('serial') or saved.get('clean_start') is not True or info.get('supervised') is not True:
        raise usb.SetupError('This experiment is only for the same supervised spare in the recorded clean-start session. No changes.')
    if options.get('test_phrase')!='TEST':raise usb.SetupError('Type TEST. No changes.')
    password=options.get('test_password','');usb.add_secret(password)
    data=password_test_profile(await asyncio.to_thread(bundled_profile),password)
    step(0);await (service or Service()).approve(info,name,phone,progress)
    fresh=await dev.find()
    if fresh.get('serial')!=info['serial'] or fresh.get('supervised') is not True or not await identity_matches(dev):
        raise usb.SetupError('Same phone and matching supervisor identity are required. No install sent.')
    from pymobiledevice3.services.mobile_config import MobileConfigService
    async with MobileConfigService(dev.client) as mc:
        before=await mc.get_profile_list()
        if IDENT in before.get('ProfileMetadata',{}):raise usb.SetupError('An enrollment profile already exists. Test stopped without replacing it.')
        progress('TEST: installing one locked MDM profile with removal-password payload. No erase or removable fallback.')
        try:await mc.install_profile_silent(usb.identity_path(),data)
        except Exception as err:
            raise usb.SetupError('iOS rejected the one-profile password experiment. No removable fallback was attempted. '+usb._redact(usb.describe_error(err))) from err
        after=await mc.get_profile_list()
        if IDENT not in after.get('ProfileMetadata',{}):raise Pending('Test install sent but profile not confirmed. Inspect Settings, do not retry automatically.')
    return {'experiment':True,'enrolled':True,'supervised':True,'removal_locked':None,'filter_active':None}

async def install_waiting(mc, key, data, progress, wait_s=600, every=15):
    """Install silently; if iOS says network error, wait for the phone to get internet (Wi-Fi) and retry."""
    import time
    start=time.monotonic(); told=False
    while True:
        try:
            await mc.install_profile_silent(key, data); return
        except Exception as err:
            if 'network error' in readable_error(err).lower() and time.monotonic()-start < wait_s:
                if not told:
                    progress('Waiting for the iPhone to get internet. On the phone join Wi-Fi now (it needs it to fetch its identity from our server). Retrying automatically for up to 10 minutes...'); told=True
                await asyncio.sleep(every); continue
            raise

async def enroll(dev, data, progress):
    from pymobiledevice3.services.mobile_config import MobileConfigService
    if not await dev._is_supervised(): raise usb.SetupError('Supervision could not be confirmed. Enrollment stopped.')
    key=usb.get_identity()
    async with MobileConfigService(dev.client) as mc:
        cfg=await mc.get_cloud_configuration()
        if not isinstance(cfg,dict) or cfg.get('IsSupervised') is not True: raise usb.SetupError('Phone did not confirm supervised configuration.')
        if usb._cert_matches(cfg,key) is not True: raise usb.SetupError('This PC does not hold the matching supervision identity. No erase or takeover will be attempted.')
        # iOS may treat an applied cloud configuration as immutable. Never rewrite
        # it during enrollment. PayloadRemovalDisallowed is validated when fetched;
        # actual non-removability still requires the server ProfileList verification.
        if cfg.get('IsMDMUnremovable') is not True:
            progress('Existing supervision does not declare a cloud management lock. Installing the locked enrollment profile; final non-removability must be verified by the server. No lock claim yet.')
        progress('Installing the enrollment using this PC\'s supervision identity.')
        await install_waiting(mc,key,data,progress)
        profiles=await mc.get_profile_list()
        if IDENT not in profiles.get('ProfileMetadata',{}): raise Pending('Enrollment sent but not yet visible on the phone. Check the dashboard. Do not erase again.')

def can_continue_clean(info, saved):
    return (saved.get('clean_start') is True and saved.get('phase') == 'erased'
            and saved.get('udid') == info.get('serial')
            and (info.get('pf',{}).get('setup_done') is False or info.get('activated') is False))

async def confirm_clean_after_activation(dev, progress):
    progress('Checking activation before reading old supervision. No erase or backup restore will be sent.')
    await dev.activate_robust(progress)
    after = await dev.connect()
    if after.get('supervised') is not False:
        raise usb.SetupError('After activation, old supervision is still present or unreadable. No supervision write or enrollment was sent. Keep the phone connected and inspect its screen and local log. Do not erase again or restore the old backup. Detail: '+str(after.get('supervised_detail','not available')))
    return after

async def continue_clean(dev, info, name, phone, options, progress, step, service=None, install=enroll, persist=save_state):
    saved=load_state()
    if not can_continue_clean(info,saved) or options.get('continue_phrase')!='CONTINUE WITHOUT ERASE':
        raise usb.SetupError('No confirmed interrupted clean start for this phone on Setup Assistant. Nothing was changed.')
    if not name.strip() or not 7 <= len(''.join(c for c in phone if c.isdigit())) <= 15:
        raise usb.SetupError('Enter a customer name and phone number.')
    fresh=await dev.find()
    fresh['pf']=await dev.preflight()
    if not can_continue_clean(fresh,saved):
        raise usb.SetupError('The phone or Setup Assistant state changed. No erase or enrollment was sent.')
    profile=options.get('_mock_profile') or await asyncio.to_thread(bundled_profile)
    step(0); grant=await (service or Service()).approve(info,name,phone,progress)
    fresh=await dev.find();fresh['pf']=await dev.preflight()
    if not can_continue_clean(fresh,saved):
        raise usb.SetupError('Phone changed after approval. No erase or enrollment was sent.')
    await confirm_clean_after_activation(dev,progress)
    step(3);await dev.activate_and_supervise(progress,show_restore=False)
    saved['phase']='supervised';persist(saved)
    step(5);await install(dev,profile,progress)
    step(6);await (service or Service()).verify(grant,progress)
    saved['phase']='verified';persist(saved)
    return {'supervised':True,'enrolled':True,'removal_locked':True,'filter_active':None,'backup_dir':saved.get('backup_dir'),'device_id':grant.get('device_id'),'clean_start':True}

async def run_activation_test(dev, info, name, phone, options, progress, step, service=None, persist=save_state, install=enroll):
    # Only the previously recorded owner spare may enter this destructive experiment.
    saved = load_state()
    if not saved.get('udid') or saved['udid'] != info.get('serial') or saved.get('clean_start') is not True:
        raise usb.SetupError('Only the same recorded owner spare is allowed. No phone changes.')
    if 'iPhone 8' not in info.get('model', ''):
        raise usb.SetupError('This test is restricted to the recorded spare iPhone 8.')
    if not name.strip() or not 7 <= len(''.join(c for c in phone if c.isdigit())) <= 15:
        raise usb.SetupError('Enter a customer name and phone number.')
    continuation = options.get('activation_continue') is True
    if continuation:
        if saved.get('experiment') != 'activation-incomplete' or saved.get('phase') != 'erased' or options.get('test_phrase') != 'CONTINUE':
            raise usb.SetupError('No interrupted activation test at the erased stage. No changes.')
    elif not (options.get('test_phrase') == 'TEST ERASE' and options.get('consent') and options.get('backup_confirmed')):
        raise usb.SetupError('Confirm this owner spare, Find My off, backup and data loss, then type TEST ERASE. No changes.')
    elif saved.get('experiment') == 'activation-incomplete' and saved.get('phase') in ('erase_requested','erased','test_supervision','test_install_sent','test_installed'):
        raise usb.SetupError('This test already started. No second erase. Inspect the phone and log first.')
    profile = options.get('_mock_profile') or await asyncio.to_thread(bundled_profile)
    step(0); grant = await (service or Service()).approve(info,name,phone,progress)
    fresh = await dev.find()
    if fresh.get('serial') != saved['udid']:
        raise usb.SetupError('Connected phone changed. No erase or install sent.')
    record = dict(saved)
    password = options.get('password',''); usb.add_secret(password)
    if not continuation:
        if fresh.get('supervised') is not True or not await identity_matches(dev):
            raise usb.SetupError('Expected matching supervised spare required. No erase.')
        step(1)
        b = await dev.backup_to_pc(progress,password=password)
        record.update(backup_dir=b['folder'], experiment='activation-incomplete', phase='backup_checked')
        persist(record)
        fresh = await dev.find()
        if fresh.get('serial') != saved['udid'] or fresh.get('supervised') is not True:
            raise usb.SetupError('Phone changed during backup. No erase sent.')
        step(2); record['phase']='erase_requested'; persist(record)
        await dev.erase_and_reconnect(progress)
        record['phase']='erased'; persist(record)
    progress('Safety backup retained. No backup restore is performed by this experiment.')
    step(3); await dev.activation_test_supervision(progress)
    record['phase']='test_supervision'; persist(record)
    # Unlike earlier builds, do not mark Setup Assistant complete before installation.
    step(5); record['phase']='test_install_sent'; persist(record)
    try:
        await install(dev,profile,progress)
    except Exception as err:
        raise usb.SetupError('iOS rejected or could not confirm the incomplete-Setup-Assistant test. No removable fallback or second erase. '+usb._redact(usb.describe_error(err))) from err
    record['phase']='test_installed'; persist(record)
    return {'experiment':True, 'activation_test':True, 'enrolled':True, 'supervised':True,
            'removal_locked':None, 'filter_active':None, 'push_verified':False, 'backup_dir':record.get('backup_dir')}

async def run_fresh_flow(dev, info, name, phone, options, progress, step, service=None, persist=save_state, install=enroll):
    """Build 11: one flow. Erase (no backup), supervise, install the one locked MDM profile, check in."""
    if not name.strip() or not 7 <= len(''.join(c for c in phone if c.isdigit())) <= 15:
        raise usb.SetupError('Enter a customer name and a phone number with 7 to 15 digits. Nothing was changed.')
    saved = load_state()
    skip_erase = options.get('skip_erase') is True
    if skip_erase:
        if not (saved.get('experiment') == 'fresh' and saved.get('udid') == info.get('serial') and saved.get('phase') in ('erased', 'supervised')):
            raise usb.SetupError('No interrupted erase for this phone. Nothing was changed.')
    elif options.get('consent') is not True:
        raise usb.SetupError('Tick the box to confirm the phone will be erased. Nothing was changed.')
    profile = options.get('_mock_profile') or await asyncio.to_thread(bundled_profile)
    step(0); grant = await (service or Service()).approve(info, name, phone, progress)
    fresh = await dev.find()
    if fresh.get('serial') != info.get('serial'):
        raise usb.SetupError('The connected phone changed. Nothing was erased.')
    record = {'udid': info['serial'], 'experiment': 'fresh', 'phase': 'approved', 'clean_start': True, 'device_id': grant.get('device_id')}
    persist(record)
    step(1)
    if not skip_erase:
        step(2); record['phase'] = 'erase_requested'; persist(record)
        await dev.erase_and_reconnect(progress)
    record['phase'] = 'erased'; persist(record)
    step(3)
    try:
        await dev.activation_test_supervision(progress)
    except usb.SetupError as err:
        usb.log('fresh flow: first supervision order failed, trying standard supervision once', err)
        progress('First supervision method was not accepted. Trying the standard method once...')
        await dev.activate_and_supervise(progress, show_restore=False)
    record['phase'] = 'supervised'; persist(record)
    step(5); record['phase'] = 'install_sent'; persist(record)
    try:
        await install(dev, profile, progress)
    except Exception as err:
        raise usb.SetupError('The phone is supervised, but iOS rejected or could not confirm the MDM profile. Do not erase again. ' + readable_error(err)) from err
    record['phase'] = 'installed'; persist(record)
    step(6); verify = 'not checked'
    try:
        await (service or Service()).verify(grant, progress)
        verify = 'server confirmed the phone checked in and the profile is non-removable'
    except Exception as err:
        verify = 'server check not confirmed yet: ' + usb._redact(usb.describe_error(err))
    record['phase'] = 'done'; persist(record)
    return {'experiment': True, 'fresh': True, 'supervised': True, 'enrolled': True, 'removal_locked': None, 'filter_active': None, 'verify': verify, 'device_id': grant.get('device_id')}

LOCK_IDENT = 'com.kosherguard.lock-test'

def lock_test_profile():
    """Separate profile: itself non-removable on a supervised phone, with supervised-only restrictions."""
    from uuid import uuid4
    return plistlib.dumps({'PayloadType':'Configuration','PayloadVersion':1,'PayloadIdentifier':LOCK_IDENT,'PayloadUUID':str(uuid4()),
        'PayloadDisplayName':'KosherGuard restrictions','PayloadOrganization':'KosherGuard','PayloadRemovalDisallowed':True,
        'PayloadContent':[{'PayloadType':'com.apple.applicationaccess','PayloadVersion':1,'PayloadIdentifier':LOCK_IDENT+'.restrictions','PayloadUUID':str(uuid4()),
          'PayloadDisplayName':'Restrictions','allowEraseContentAndSettings':False,'allowUIConfigurationProfileInstallation':False}]})

def summarize_profiles(pl):
    out=[]
    meta=(pl or {}).get('ProfileMetadata',{}); man=(pl or {}).get('ProfileManifest',{})
    for ident in meta:
        m=man.get(ident,{}) if isinstance(man,dict) else {}
        keep={k:v for k,v in m.items() if isinstance(v,(bool,str,int))}
        out.append(ident+' '+str(keep))
    return out

async def remove_lock_test(dev, progress):
    from pymobiledevice3.services.mobile_config import MobileConfigService
    key=usb.get_identity()
    async with MobileConfigService(dev.client) as mc:
        await mc.escalate(key)
        await mc.remove_profile(LOCK_IDENT)
        after=await mc.get_profile_list()
    if LOCK_IDENT in after.get('ProfileMetadata',{}): raise usb.SetupError('The restrictions profile is still on the phone.')
    return {'removed_lock_test':True,'profiles':summarize_profiles(after)}

def readable_error(err):
    """Turn an iOS CommandErrorArchive into plain sentences; fall back to the usual text."""
    import re
    try:
        text=str(err)
        m=re.search(r"CommandErrorArchive': b(['\"])(.*?)\1[,}]",text,re.S)
        if m:
            import ast
            raw=ast.literal_eval('b'+m.group(1)+m.group(2)+m.group(1))
            seen=[]
            for r in re.findall(rb'[A-Za-z][ -~]{14,}',raw):
                t=r.decode('latin1').strip()
                t=re.sub(r'^[a-z](?=[A-Z])','',t)
                if t and t not in seen and 'Domain' not in t and not t.startswith(('NS','USEnglish')):seen.append(t)
            if seen:return 'iOS said: '+' / '.join(seen)
    except Exception:pass
    return usb._redact(usb.describe_error(err))

async def run_resume_flow(dev, info, name, phone, options, progress, step, service=None, persist=save_state, install=None):
    """Build 12: phone already supervised by this PC. No erase. Install MDM removable, test lock ideas."""
    if info.get('supervised') is not True:
        raise usb.SetupError('This step needs the phone to be supervised already. Nothing was changed.')
    if not name.strip() or not 7 <= len(''.join(c for c in phone if c.isdigit())) <= 15:
        raise usb.SetupError('Enter a customer name and a phone number with 7 to 15 digits. Nothing was changed.')
    mock = options.get('_mock_profile')
    if not mock and not await identity_matches(dev):
        raise usb.SetupError('This PC does not hold the supervision identity this phone was supervised with. Nothing was changed, no erase.')
    profile = mock or await asyncio.to_thread(bundled_profile, True)
    step(0); grant = await (service or Service()).approve(info, name, phone, progress)
    fresh = await dev.find()
    if fresh.get('serial') != info.get('serial'):
        raise usb.SetupError('The connected phone changed. Nothing was installed.')
    notes = []
    key = None if mock else usb.get_identity()
    from pymobiledevice3.services.mobile_config import MobileConfigService
    step(5)
    async with MobileConfigService(dev.client) as mc:
        before = await mc.get_profile_list()
        if IDENT in before.get('ProfileMetadata', {}):
            notes.append('MDM profile was already on the phone.')
        else:
            progress('Installing the KosherGuard MDM profile (removable, because iOS refuses a locked MDM profile). The iPhone must be online (Wi-Fi) to fetch its identity from our server.')
            try:
                await install_waiting(mc, key, profile, progress)
            except Exception as err:
                last = err
                hint = ' On the iPhone connect to Wi-Fi (Settings > Wi-Fi), open Safari to confirm the internet works, then run this step again. No erase is needed.' if 'network error' in readable_error(err).lower() else ''
                raise usb.SetupError('iOS would not install the MDM profile. Phone stays supervised. Do not erase. ' + readable_error(err) + hint) from err
            after = await mc.get_profile_list()
            if IDENT not in after.get('ProfileMetadata', {}):
                raise Pending('Install sent but the profile is not visible yet. Do not erase. Check Settings > General > VPN & Device Management.')
            notes.append('MDM profile installed (removable).')
        cfg = await mc.get_cloud_configuration()
        notes.append('Phone cloud setting IsMDMUnremovable = ' + str((cfg or {}).get('IsMDMUnremovable')))
    persist({'udid': info['serial'], 'experiment': 'fresh', 'phase': 'mdm_installed', 'clean_start': True})
    step(6)
    try:
        await (service or Service()).verify(grant, progress)
        notes.append('Server: phone checked in and enrollment confirmed.')
    except Exception as err:
        notes.append('Server check-in not confirmed: ' + usb._redact(usb.describe_error(err)))
    if options.get('extras', True):
        progress('Testing a separate non-removable restrictions profile (blocks erase from Settings and profile installs from Settings).')
        try:
            async with MobileConfigService(dev.client) as mc:
                before = await mc.get_profile_list()
                if LOCK_IDENT not in before.get('ProfileMetadata', {}):
                    await mc.install_profile_silent(key, lock_test_profile())
                after = await mc.get_profile_list()
            notes.append('Restrictions profile ' + ('installed' if LOCK_IDENT in after.get('ProfileMetadata', {}) else 'NOT visible after install'))
        except Exception as err:
            notes.append('Restrictions profile rejected: ' + usb._redact(usb.describe_error(err)))
    async with MobileConfigService(dev.client) as mc:
        final = await mc.get_profile_list()
    prof = summarize_profiles(final)
    usb.log('resume flow profiles: ' + ' | '.join(prof))
    return {'experiment': True, 'resume12': True, 'supervised': True, 'enrolled': IDENT in final.get('ProfileMetadata', {}), 'notes': notes, 'profiles': prof}

async def run_flow(dev, info, name, phone, options, progress, step, service=None, install=enroll, persist=save_state):
    if options.get('keyless'):
        return await run_keyless(dev,info,options,progress)
    if options.get('lab'):
        return await run_lab(dev,info,options,progress)
    if options.get('resume12'):
        return await run_resume_flow(dev,info,name,phone,options,progress,step,service,persist,install)
    if options.get('fresh'):
        return await run_fresh_flow(dev,info,name,phone,options,progress,step,service,persist,install)
    if options.get('activation_test'):
        return await run_activation_test(dev,info,name,phone,options,progress,step,service,persist,install)
    if options.get('password_test'):
        return await run_password_test(dev,info,name,phone,options,progress,step,service)
    if options.get('continue_clean'):
        return await continue_clean(dev,info,name,phone,options,progress,step,service,install,persist)
    if info.get('supervised') is None: raise usb.SetupError('Supervision is unknown. Nothing will be erased.')
    if not name.strip() or not 7 <= len(''.join(c for c in phone if c.isdigit())) <= 15: raise usb.SetupError('Enter a customer name and a phone number with 7 to 15 digits.')
    transfer=options.get('transfer') is True
    if transfer and (info.get('supervised') is not True or options.get('resume')):
        raise usb.SetupError('Clean start requires a confirmed supervised phone and cannot be combined with resume.')
    if transfer and not (options.get('owner_phrase')=='OWN SPARE ERASE' and options.get('consent') and options.get('backup_confirmed')):
        raise usb.SetupError('Clean start requires owner-only spare-phone confirmation, data-loss agreement and Find My off. Nothing was erased.')
    needs_erase=(info['supervised'] is False or transfer) and not options.get('resume')
    if options.get('resume') and options.get('clean_start'):
        raise usb.SetupError('Interrupted clean-start setup requires inspection. No backup restore or second erase was started.')
    if options.get('resume') and info.get('pf',{}).get('setup_done') is not False and info.get('activated') is not False:
        raise usb.SetupError('Resume is only allowed when the phone is confirmed on its setup screens. No erase or restore was started.')
    if needs_erase and not (options.get('consent') and options.get('erase')=='ERASE' and options.get('backup_confirmed')):
        raise usb.SetupError('Owner consent, an independent usable backup and ERASE confirmation are required. Nothing was changed.')
    if not transfer and not options.get('_mock_profile') and info.get('supervised') is True and not usb.identity_path().exists():
        raise usb.SetupError('This PC has no supervision identity. Import the original matching identity before enrolling this already supervised phone. No new identity was created.')
    profile=options.get('_mock_profile') or await asyncio.to_thread(bundled_profile)
    step(0); grant=await (service or Service()).approve(info,name,phone,progress)
    # Re-read exactly the selected phone before destructive work.
    fresh=await dev.find()
    if fresh['serial']!=info['serial']: raise usb.SetupError('The connected phone changed. Setup stopped.')
    if fresh.get('supervised') is None or (needs_erase and fresh.get('supervised') is not info['supervised']): raise usb.SetupError('The supervision state changed. Check the phone again before continuing.')
    if not transfer and not options.get('_mock_profile') and fresh.get('supervised') is True and not await identity_matches(dev):
        raise usb.SetupError('This PC has no matching supervision identity. For your OWN spare phone only, go back and choose the separate clean-erase path. No erase was sent.')
    record={'udid':info['serial'],'phase':'approved','backup_dir':options.get('backup_dir'),'restore_done':bool(options.get('restore_done')),'device_id':grant.get('device_id'),'clean_start':transfer}
    password=options.get('password',''); usb.add_secret(password)
    usb.get_identity() if not options.get('_mock_profile') else None
    backup_dir=options.get('backup_dir')
    if options.get('resume'):
        if not options.get('_mock_profile'):
            pf=await dev.preflight()
            if pf.get('setup_done') is not False:
                raise usb.SetupError('Setup Assistant state is no longer confirmed. Resume stopped without erase or restore.')
        if not backup_dir: raise usb.SetupError('No saved backup selected. No second erase is permitted.')
        await asyncio.to_thread(usb.verify_backup, Path(backup_dir), info['serial'], password)
    elif needs_erase:
        step(1)
        if options.get('backup',True):
            b=await dev.backup_to_pc(progress,password=password); backup_dir=b['folder'];record['backup_dir']=backup_dir
        record['phase']='backup_checked';persist(record)
        # A cable swap during a long backup must never redirect the erase.
        before_erase=await dev.find()
        if before_erase.get('serial')!=info['serial'] or before_erase.get('supervised') is not info['supervised']:
            raise usb.SetupError('The selected phone or supervision state changed during backup. Nothing was erased.')
        step(2);record['phase']='erase_requested';persist(record)
        after=await dev.erase_and_reconnect(progress);record['phase']='erased';persist(record)
        if transfer:
            await confirm_clean_after_activation(dev,progress)
    if transfer:
        progress('Old data backup retained only. No old supervised backup will be restored automatically.')
    if info.get('supervised') is not True or transfer:
        step(3);await dev.activate_and_supervise(progress,show_restore=False);record['phase']='supervised';persist(record)
    if backup_dir and not transfer and not options.get('restore_done'):
        step(4);progress('Restoring data, excluding management and selected settings. This is not a full identical restore.')
        await dev.restore_from_pc(backup_dir,progress,password=password);record['restore_done']=True;record['phase']='restored';persist(record)
        await dev.ensure_supervised(progress)
    step(5);await install(dev,profile,progress)
    step(6);await (service or Service()).verify(grant,progress)
    record['phase']='verified';persist(record)
    return {'supervised':True,'enrolled':True,'removal_locked':True,'filter_active':None,'backup_dir':backup_dir,'device_id':grant.get('device_id'),'clean_start':transfer}


# ---- Lab build: reversible cable tests of MDM install shapes (no erase, no server calls except the enrollment file) ----
LAB_SHAPES = [
    ('L1', 'MDM profile alone, locked flag (as shipped)'),
    ('L2', 'MDM profile + restrictions payload, locked flag'),
    ('L3', 'Removable outer profile, locked flag put inside each payload'),
    ('L4', 'Locked profile, cable install WITH a prompt on the phone (you tap Install)'),
    ('L5', 'Locked profile installed on top of the existing one (no removal first)'),
]

def lab_profile(shape, data):
    from uuid import uuid4
    p = plistlib.loads(data)
    if shape in ('L1', 'L4', 'L5'):
        return plistlib.dumps(p)
    if shape == 'L2':
        p['PayloadContent'].append({'PayloadType':'com.apple.applicationaccess','PayloadVersion':1,'PayloadIdentifier':IDENT+'.lab-restrictions','PayloadUUID':str(uuid4()),'allowEraseContentAndSettings':False})
        return plistlib.dumps(p)
    if shape == 'L3':
        p['PayloadRemovalDisallowed'] = False
        for x in p['PayloadContent']:
            x['PayloadRemovalDisallowed'] = True
        return plistlib.dumps(p)
    raise usb.SetupError('Unknown test shape.')

async def run_lab(dev, info, options, progress):
    import re, time
    shape = options.get('shape')
    if info.get('supervised') is not True:
        raise usb.SetupError('Phone is not confirmed supervised. Nothing changed.')
    if not await identity_matches(dev):
        raise usb.SetupError('This PC does not hold the supervision identity for this phone. Nothing changed.')
    from pymobiledevice3.services.mobile_config import MobileConfigService
    key = usb.get_identity()
    notes = []; lines = []; stop = asyncio.Event()
    pat = re.compile(r'ManagedConfiguration|MCProfile|mdmd|profiled|removable|MDM|ConfigurationProfiles', re.I)
    async def capture():
        try:
            from pymobiledevice3.services.os_trace import OsTraceService
            svc = OsTraceService(dev.client)
            async for e in svc.syslog():
                if stop.is_set(): break
                txt = ' | '.join(str(getattr(e, a, '') or '') for a in ('filename', 'subsystem', 'message'))
                if pat.search(txt) and len(lines) < 60:
                    lines.append(usb._redact(txt)[:320])
        except Exception as err:
            lines.append('(phone log not readable: ' + usb._redact(usb.describe_error(err))[:200] + ')')
    if shape == 'RESTORE':
        data = await asyncio.to_thread(bundled_profile, True)
    else:
        data = lab_profile(shape, await asyncio.to_thread(bundled_profile, False))
    async with MobileConfigService(dev.client) as mc:
        before = await mc.get_profile_list()
        have = IDENT in before.get('ProfileMetadata', {})
        notes.append('Before: ' + (' | '.join(summarize_profiles(before)) or 'no profiles'))
        if have and shape != 'L5':
            progress('Removing the current MDM profile first (it will be restored at the end).')
            await mc.escalate(key)
            await mc.remove_profile(IDENT)
            notes.append('Removed the existing MDM profile first.')
        task = asyncio.create_task(capture())
        await asyncio.sleep(2)
        outcome = 'ACCEPTED'
        try:
            progress('Installing test shape ' + str(shape) + '. If the phone shows an Install prompt, tap Install.' )
            if shape == 'L4':
                await mc.install_profile(data)
            else:
                await mc.install_profile_silent(key, data)
        except Exception as err:
            outcome = 'REFUSED: ' + usb._redact(readable_error(err))
            notes.append('Raw: ' + usb._redact(str(err))[:500])
        await asyncio.sleep(3)
        stop.set()
        task.cancel()
        after = await mc.get_profile_list()
        meta = after.get('ProfileMetadata', {}).get(IDENT, {})
        cfg = await mc.get_cloud_configuration()
    notes.insert(0, 'Shape ' + str(shape) + ': ' + outcome)
    notes.append('After: ' + (' | '.join(summarize_profiles(after)) or 'no profiles'))
    notes.append('MDM profile present: ' + str(IDENT in after.get('ProfileMetadata', {})) + '; IsMDMUnremovable = ' + str((cfg or {}).get('IsMDMUnremovable')))
    for l in lines[:15]:
        notes.append('log: ' + l)
    return {'lab': True, 'notes': notes, 'profiles': summarize_profiles(after)}


# ---- Build 21: keyless lab (no supervision key needed; every install shows a prompt on the phone) ----
KEYLESS_SHAPES = [
    ('K1', 'Locked MDM profile, install with prompt on the phone'),
    ('K2', 'Normal removable MDM profile, install with prompt (control)'),
    ('K3', 'Locked MDM profile + restrictions payload, install with prompt'),
    ('K4', 'Locked profile with NO MDM payload, install with prompt (control)'),
]

def keyless_profile(shape, data):
    from uuid import uuid4
    p = plistlib.loads(data)
    if shape == 'K2':
        p['PayloadRemovalDisallowed'] = False
    elif shape == 'K3':
        p['PayloadContent'].append({'PayloadType':'com.apple.applicationaccess','PayloadVersion':1,'PayloadIdentifier':IDENT+'.lab-restrictions','PayloadUUID':str(uuid4()),'allowEraseContentAndSettings':False})
    elif shape == 'K4':
        return plistlib.dumps({'PayloadType':'Configuration','PayloadVersion':1,'PayloadIdentifier':'com.kosherguard.lab-k4','PayloadUUID':str(uuid4()),
            'PayloadDisplayName':'KosherGuard lab control','PayloadOrganization':'KosherGuard','PayloadRemovalDisallowed':True,
            'PayloadContent':[{'PayloadType':'com.apple.applicationaccess','PayloadVersion':1,'PayloadIdentifier':'com.kosherguard.lab-k4.r','PayloadUUID':str(uuid4()),'allowAirDrop':True}]})
    return plistlib.dumps(p)

async def run_keyless(dev, info, options, progress):
    import re
    shape = options.get('shape')
    from pymobiledevice3.services.mobile_config import MobileConfigService
    notes = []; lines = []; stop = asyncio.Event()
    pat = re.compile(r'ManagedConfiguration|MCProfile|mdmd|profiled|removable|MDM|ConfigurationProfiles|not allowed|restrict', re.I)
    async def capture():
        try:
            from pymobiledevice3.services.os_trace import OsTraceService
            svc = OsTraceService(dev.client)
            async for e in svc.syslog():
                if stop.is_set(): break
                txt = ' | '.join(str(getattr(e, a, '') or '') for a in ('filename', 'subsystem', 'message'))
                if pat.search(txt) and len(lines) < 60:
                    lines.append(usb._redact(txt)[:320])
        except Exception as err:
            lines.append('(phone log not readable: ' + usb._redact(usb.describe_error(err))[:200] + ')')
    data = keyless_profile(shape, await asyncio.to_thread(bundled_profile, False))
    async with MobileConfigService(dev.client) as mc:
        before = await mc.get_profile_list()
        notes.append('Before: ' + (' | '.join(summarize_profiles(before)) or 'no profiles'))
        if shape != 'K4' and IDENT in before.get('ProfileMetadata', {}):
            raise usb.SetupError('The MDM profile is already on the phone, so this test cannot run. Nothing changed.')
        task = asyncio.create_task(capture())
        await asyncio.sleep(2)
        outcome = 'ACCEPTED'
        try:
            progress('Look at the iPhone now. If it shows an Install prompt or a Profile Downloaded notice, open it and tap Install, then enter the passcode.')
            await mc.install_profile(data)
        except Exception as err:
            outcome = 'REFUSED: ' + usb._redact(readable_error(err))
            notes.append('Raw: ' + usb._redact(str(err))[:500])
        await asyncio.sleep(3)
        stop.set(); task.cancel()
        after = await mc.get_profile_list()
        cfg = await mc.get_cloud_configuration()
    notes.insert(0, 'Shape ' + str(shape) + ': ' + outcome)
    notes.append('After: ' + (' | '.join(summarize_profiles(after)) or 'no profiles'))
    notes.append('IsMDMUnremovable = ' + str((cfg or {}).get('IsMDMUnremovable')))
    for l in lines[:15]:
        notes.append('log: ' + l)
    return {'lab': True, 'notes': notes, 'profiles': summarize_profiles(after)}
