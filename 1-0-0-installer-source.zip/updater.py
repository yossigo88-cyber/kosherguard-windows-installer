"""Owner-clicked updater. Downloads only fixed-repository GitHub release assets."""
import hashlib,json,os,subprocess,sys,tempfile
from pathlib import Path
from urllib.parse import urlparse
import requests
REPO='yossigo88-cyber/kosherguard-windows-installer'
BUILD=4
try:
 from build_version import BUILD
except ImportError:pass
class UpdateError(Exception):pass
def allowed(url):
 u=urlparse(url)
 return u.scheme=='https' and u.netloc=='github.com' and u.path.startswith('/'+REPO+'/releases/download/')
def find_update(session=requests):
 r=session.get('https://api.github.com/repos/'+REPO+'/releases',timeout=15);r.raise_for_status();rows=r.json()
 for row in rows:
  tag=row.get('tag_name','')
  if row.get('draft') or not tag.startswith('test-build-'):continue
  try:n=int(tag.removeprefix('test-build-'))
  except ValueError:continue
  if n<=BUILD:continue
  for a in row.get('assets',[]):
   digest=a.get('digest','')
   if a.get('name')=='KosherGuard-Setup.exe' and allowed(a.get('browser_download_url','')) and len(digest)==71 and digest.startswith('sha256:'):
    try:int(digest[7:],16)
    except ValueError:continue
    return {'number':n,'url':a['browser_download_url'],'sha256':digest[7:],'size':a.get('size',0)}
 return None
def download(update,session=requests):
 if not allowed(update.get('url','')):raise UpdateError('Unexpected update address.')
 folder=Path(tempfile.mkdtemp(prefix='KosherGuard-update-'));p=folder/'KosherGuard-Setup.exe'
 h=hashlib.sha256();total=0
 try:
  with session.get(update['url'],stream=True,timeout=60) as r:
   r.raise_for_status()
   with p.open('wb') as f:
    for b in r.iter_content(1024*1024):
     total+=len(b)
     if total>300*1024*1024:raise UpdateError('Update is too large.')
     h.update(b);f.write(b)
  if total!=update['size'] or h.hexdigest()!=update['sha256']:raise UpdateError('Update checksum failed. Existing app was not changed.')
  with p.open('rb') as f:
   if f.read(2)!=b'MZ':raise UpdateError('Update is not a Windows executable.')
  return p
 except Exception:
  p.unlink(missing_ok=True);raise

def stage_replace(new_path):
 if os.name!='nt' or not getattr(sys,'frozen',False):raise UpdateError('Automatic replacement requires the Windows executable.')
 target=Path(sys.executable).resolve();source=Path(new_path).resolve()
 # No paths enter shell syntax: PowerShell reads a JSON record as literal strings.
 folder=source.parent;record=folder/'replace.json'
 record.write_text(json.dumps({'pid':os.getpid(),'target':str(target),'source':str(source),'backup':str(target)+'.previous'}))
 script=folder/'replace.ps1'
 script.write_text("""$ErrorActionPreference='Stop'
$c=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'replace.json') -Raw | ConvertFrom-Json
try { Wait-Process -Id $c.pid -Timeout 120 -ErrorAction SilentlyContinue } catch {}
if (Get-Process -Id $c.pid -ErrorAction SilentlyContinue) { exit 1 }
try {
 Copy-Item -LiteralPath $c.target -Destination $c.backup -Force
 Copy-Item -LiteralPath $c.source -Destination $c.target -Force
 Start-Process -FilePath $c.target
} catch {
 if (Test-Path -LiteralPath $c.backup) { Copy-Item -LiteralPath $c.backup -Destination $c.target -Force }
 $_ | Out-File -LiteralPath (Join-Path $PSScriptRoot 'update-error.txt')
}
""")
 subprocess.Popen(['powershell.exe','-NoProfile','-ExecutionPolicy','Bypass','-File',str(script)],creationflags=0x08000000,close_fds=True)
