# KosherGuard desktop setup, spare-phone test build

Python/Tkinter iPhone-only app, adapted visually and in USB backup routines from the owner's v5.6.2 source. Uses admin.kosherguard.xyz and mdm.kosherguard.xyz. No third-party MDM or Android flows.

## Download and run
Download KosherGuard-Setup.exe from this release and open it on Windows. Python is not required for the executable. Apple Devices from Microsoft Store supplies the iPhone USB driver. This is an unsigned spare-phone TEST build, so Windows may show a reputation warning. Do not use on a customer's phone yet.

Built on GitHub's free standard Windows 2022 runner with Python 3.12 and PyInstaller. Twenty-seven mocked safety tests passed. The packaged executable itself launched on Windows and passed a Tkinter preview/import self-test with no USB or network calls. This is not a full interactive Windows or physical iPhone test. Screen previews were also inspected separately. Existing hosted installer was not replaced.

For a safe look without a phone: run KosherGuard-Setup.exe --preview from a terminal. For ordinary setup, double-click the executable. Read all erase/backup warnings before continuing. This does not verify the website filter or guarantee restoration/removal resistance.

## Real work and limits
Discovery reads one USB iPhone only. The user must approve the detected phone in the existing dashboard before work starts. First-time supervision requires owner consent, Find My off, an independent usable backup and typing ERASE. The selected phone is re-read before destructive work. Unknown supervision stops setup. Already supervised phones require this PC's matching supervision identity.

The existing supervision identity lives under %APPDATA%\KosherGuard\supervision-identity.pem. Back it up privately. Do not replace it to take over an already supervised phone. If the old PowerShell installer has already created a different identity beside its script, restore/copy that SAME identity to this location before managing those phones. This new ZIP includes no identity, password, token or live enrollment profile.

The enrollment profile is downloaded from the currently shipped installer URL, checked for the own-MDM endpoints, then installed using the supervision identity. A server ProfileList verification must confirm the enrollment lock before the result says management verified. iOS can reject cloud-configuration writes. A timeout does not prove failure or success. This installer does not prove that the website filter is active and does not add a DNS or VPN payload itself.

Backups are local. Integrity checks require all manifest-listed files, but cannot prove a successful restore. Restore intentionally excludes management and selected system settings and is NOT an identical restore. A full manifest copy is retained, and the original manifest is restored after the restore attempt. Keep an independent backup. No eSIM preservation guarantee; the USB erase requests preservation, but real carrier/device checks remain necessary.

Interrupted setup saves a local phase and backup folder, not the dashboard secret or backup password. Resume is offered only for the same phone on confirmed setup screens with a saved backup. It never sends another erase. If state is unclear, stop and inspect instead of guessing. The app may need the phone unlocked or setup completed before enrollment; a rejected operation stops with a clear message.

Before use with customers: full interactive Windows test, then a spare-phone backup/erase/restore/enrollment/removal test. No physical phone was touched during development.

## Tests
python -m unittest discover -s tests -v
Screenshots use --preview with sample state. They are UI previews, not evidence of real enrollment.

## Owner-only clean start for an old filter
For a spare phone that belongs to you, choose My OWN spare phone: clean start. This is a separate destructive path even when the phone reports supervised. Find My must be off. Save all needed data elsewhere and type ERASE plus OWN SPARE ERASE. Dashboard approval and same-phone checks still apply. An optional local backup is retained but NOT restored automatically. A backup from the same supervised phone can restore its old profiles/supervision.

The USB erase is an attempt, not a guaranteed way past old policy. If refused, restore using Apple Devices on Windows (recovery mode if necessary), then reconnect. Activation Lock still needs the owner's Apple Account; automated organization enrollment may return and needs its organization's release. There is no bypass. After erase, the installer requires old supervision gone, then attempts fresh supervision and own-MDM enrollment. If interrupted after a recorded erase, a separate Continue clean start (NO ERASE) is offered only for the same phone while Setup Assistant or unactivated state is confirmed. Type CONTINUE WITHOUT ERASE. It activates first, then requires old supervision confirmed gone before writing new supervision. No automatic old-backup restore and no second erase. If the state is unknown, stop for inspection. This path is mock-tested and packaged self-tested, not physically tested.

## Updates
This build checks this fixed GitHub repository for newer test-build releases when launched idle. Click Update to download and check the release asset SHA256 and size. It will not offer replacement while phone setup is running. The old executable is retained as .previous for recovery. The update helper waits for this process to close, replaces the app and relaunches. No admin prompt or paid service is required. If the app folder is not writable, replacement may fail; use the release download instead. Network failures do not block ordinary setup. Updates require one new download of this updater-enabled build first. The native helper/replacement lifecycle remains untested end-to-end; checksum/selection logic is tested. A GitHub digest protects transport/integrity, not a compromised repository; this is not code signing.

Build 4 fixes checking supervision too early after erase: activation now comes before the old-supervision removal read. Unknown still stops before supervision writes or enrollment.
