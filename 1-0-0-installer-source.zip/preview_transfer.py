import app,subprocess
a=app.App(True);a.info=a.sample();a.info['supervised']=True;a.found(a.info);a.root.update();subprocess.run(['import','-window',str(a.root.winfo_id()),'/downloads/kg-clean-start-choice.png'])
a.details(transfer=True);a.root.update();subprocess.run(['import','-window',str(a.root.winfo_id()),'/downloads/kg-clean-start-top.png']);a.canvas.yview_moveto(1);a.root.update();subprocess.run(['import','-window',str(a.root.winfo_id()),'/downloads/kg-clean-start-consent.png']);a.root.destroy()
