"""Render sample screens only. Does not call USB/network."""
from pathlib import Path
import subprocess
import app
out=Path(__file__).parent/'screenshots'
a=app.App(preview=True)
a.info=a.sample()
def snap(name):
 a.root.update();a.root.update_idletasks()
 subprocess.run(['import','-window',str(a.root.winfo_id()),str(out/(name+'.png'))],check=True)
def show(name,fn):fn();snap(name)
show('01-welcome',a.welcome)
show('02-detected',lambda:a.found(a.info))
show('03-consent-top',a.details)
a.canvas.yview_moveto(1);snap('04-consent-bottom')
show('05-progress',a.working)
show('06-phone-setup',a.phone_wait)
show('07-resume',lambda:a.details({'phase':'erased','backup_dir':'Sample backup folder'}))
show('08-verified-sample',lambda:a.result({'supervised':True,'enrolled':True,'removal_locked':True,'filter_active':None}))
show('09-stopped',lambda:a.error(app.usb.SetupError('Sample: backup verification failed. No erase was started.')))
show('10-pending',lambda:a.error(app.engine.Pending('Sample: the phone has not yet confirmed enrollment.')))
a.info['supervised']=None
show('11-unknown',lambda:a.found(a.info))
a.info['supervised']=True
show('12-already-supervised',a.details)
a.root.destroy()
