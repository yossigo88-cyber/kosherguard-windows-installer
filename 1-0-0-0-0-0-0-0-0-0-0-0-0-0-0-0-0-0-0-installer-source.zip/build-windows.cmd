@echo off
setlocal
cd /d "%~dp0"
py -3.12 -m venv .build
if errorlevel 1 goto fail
.build\Scripts\python -m pip install -r requirements.txt pyinstaller==6.17.0
if errorlevel 1 goto fail
.build\Scripts\python -m PyInstaller --noconfirm --clean --onefile --windowed --name KosherGuard-Setup --collect-all pymobiledevice3 --collect-all zeroconf --hidden-import usb_engine --hidden-import setup_engine app.py
if errorlevel 1 goto fail
echo Build created: dist\KosherGuard-Setup.exe
pause
exit /b 0
:fail
echo Build failed. No phone was touched. Send the error screenshot.
pause
exit /b 1
