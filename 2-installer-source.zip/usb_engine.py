# USB/backup routines adapted from owner-provided KosherGuard v5.6.2. Hardware validation pending.
from __future__ import annotations
import asyncio
import os
import plistlib
import re
import time
from pathlib import Path
ORG = 'KosherGuard'

class SetupError(Exception):
    pass

class CloudConfigError(SetupError):
    pass

def identity_path() -> Path:
    base = Path(os.environ.get('APPDATA', '')) if os.name == 'nt' and os.environ.get('APPDATA') else Path.home() / '.kosherguard'
    return base / 'KosherGuard' / 'supervision-identity.pem' if os.name == 'nt' else base / 'supervision-identity.pem'

def get_identity() -> Path:
    from pymobiledevice3.ca import create_keybag_file
    path = identity_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    if not path.exists():
        with path.open('xb'):
            pass
        try:
            create_keybag_file(path, ORG)
            if os.name != 'nt':
                path.chmod(384)
        except Exception:
            path.unlink(missing_ok=True)
            raise
    if path.stat().st_size == 0:
        raise SetupError(f'Supervision identity is empty: {path}. Restore your backup; do not overwrite it.')
    from cryptography import x509
    from cryptography.hazmat.primitives import serialization
    data = path.read_bytes()
    try:
        x509.load_pem_x509_certificate(data)
        serialization.load_pem_private_key(data, password=None)
    except Exception as e:
        raise SetupError(f'Supervision identity is damaged: {path}. Restore your backup. ({e})') from e
    return path
LIB_SKIP_SETUP = ('Location', 'Restore', 'SIMSetup', 'Android', 'AppleID', 'IntendedUser', 'TOS', 'Siri', 'ScreenTime', 'Diagnostics', 'SoftwareUpdate', 'Passcode', 'Biometric', 'Payment', 'Zoom', 'DisplayTone', 'MessagingActivationUsingPhoneNumber', 'HomeButtonSensitivity', 'CloudStorage', 'ScreenSaver', 'TapToSetup', 'Keyboard', 'PreferredLanguage', 'SpokenLanguage', 'WatchMigration', 'OnBoarding', 'TVProviderSignIn', 'TVHomeScreenSync', 'Privacy', 'TVRoom', 'iMessageAndFaceTime', 'AppStore', 'Safety', 'Multitasking', 'ActionButton', 'TermsOfAddress', 'AccessibilityAppearance', 'Welcome', 'Appearance', 'RestoreCompleted', 'UpdateCompleted', 'WiFi', 'Display', 'Tone', 'LanguageAndLocale', 'TouchID', 'TrueToneDisplay', 'FileVault', 'iCloudStorage', 'iCloudDiagnostics', 'Registration', 'DeviceToDeviceMigration', 'UnlockWithWatch', 'Accessibility', 'All', 'ExpressLanguage', 'Language', 'N/A', 'Region', 'Avatar', 'DeviceProtection', 'Key', 'LockdownMode', 'Wallpaper', 'PrivacySubtitle', 'SecuritySubtitle', 'DataSubtitle', 'AppleIDSubtitle', 'AppearanceSubtitle', 'PreferredLang', 'OnboardingSubtitle', 'AppleTVSubtitle', 'Intelligence', 'WebContentFiltering', 'CameraButton', 'AdditionalPrivacySettings', 'EnableLockdownMode', 'OSShowcase', 'SafetyAndHandling', 'Tips', 'AgeBasedSafetySettings', 'LiquidGlass')
RESTORE_UNSKIP = ('Restore', 'RestoreCompleted', 'AppleID', 'TOS', 'WiFi', 'All')
RESTORE_LOST_MSG = 'Supervision was not confirmed after restore. Management setup stopped.'
RESTORE_LOST_HELP = ' Stop here, retain the backup, and inspect the phone with your helper. Do not erase again.'
MDM_SHOW_PANES = ('WiFi', 'Language', 'Region', 'LanguageAndLocale', 'PreferredLanguage', 'PreferredLang', 'All', 'N/A', 'Key')

def cloud_configuration(organization: str, keybag_file, show_restore: bool=False, magic: str | None=None, mdm: dict | None=None) -> dict:
    from uuid import uuid4
    from cryptography import x509
    from cryptography.hazmat.primitives.serialization import Encoding
    cer = x509.load_pem_x509_certificate(Path(keybag_file).read_bytes())
    public_key = cer.public_bytes(Encoding.DER)
    skip = [k for k in LIB_SKIP_SETUP if not (show_restore and k in RESTORE_UNSKIP)]
    cfg = {'AllowPairing': True, 'CloudConfigurationUIComplete': True, 'ConfigurationSource': 2, 'ConfigurationWasApplied': True, 'IsMDMUnremovable': False, 'IsMandatory': True, 'IsMultiUser': False, 'IsSupervised': True, 'OrganizationMagic': magic or str(uuid4()), 'OrganizationName': organization, 'PostSetupProfileWasInstalled': True, 'SkipSetup': skip, 'SupervisorHostCertificates': [public_key]}
    return cfg
SKIPPED_RESTORE_MSG = 'The Restore screen will NOT appear, because an earlier run already set up the phone without it. Your iCloud data still comes back when you sign in.'

def log_path() -> Path:
    if os.name == 'nt' and os.environ.get('APPDATA'):
        return Path(os.environ['APPDATA']) / 'KosherGuard' / 'setup-log.txt'
    return Path.home() / '.kosherguard' / 'setup-log.txt'

def log(msg: str, exc: BaseException | None=None) -> None:
    try:
        import traceback
        p = log_path()
        p.parent.mkdir(parents=True, exist_ok=True)
        with p.open('a', encoding='utf-8') as f:
            f.write(time.strftime('%Y-%m-%d %H:%M:%S ') + _redact(str(msg)) + '\n')
            if exc is not None:
                f.write(_redact(''.join(traceback.format_exception(type(exc), exc, exc.__traceback__))))
                f.write('\n')
    except Exception:
        pass

def describe_error(e: BaseException) -> str:
    (parts, seen, cur) = ([], set(), e)
    while cur is not None and id(cur) not in seen and (len(parts) < 4):
        seen.add(id(cur))
        bits = [f'{type(cur).__module__}.{type(cur).__name__}', repr(cur)]
        txt = str(cur).strip()
        if txt and txt not in repr(cur):
            bits.append(txt)
        for a in list(getattr(cur, 'args', ()) or ()) + [getattr(cur, n, None) for n in ('response', 'ErrorChain', 'error_chain', 'data')]:
            if isinstance(a, dict):
                ch = a.get('ErrorChain')
                bits.append('ErrorChain=' + repr(ch) if ch is not None else 'response=' + repr(a)[:800])
            elif isinstance(a, list) and a and isinstance(a[0], dict):
                bits.append('ErrorChain=' + repr(a)[:800])
        name = type(cur).__name__
        if name == 'CloudConfigurationAlreadyPresentError':
            bits.append('(the phone says a supervision/cloud configuration is ALREADY on it)')
        parts.append(' | '.join(bits))
        cur = cur.__cause__ or cur.__context__
    out = ' <- caused by: '.join(parts)
    return out or f'{type(e).__name__} (no message)'

def error_detail(e: BaseException) -> str:
    return f'Detail: {describe_error(e)}. Full log: {log_path()}'

def summarize_cloud(cfg) -> str:
    if not isinstance(cfg, dict):
        return f'no cloud configuration ({cfg!r})'
    sk = cfg.get('SkipSetup') or []
    return f"IsSupervised={cfg.get('IsSupervised')!r} OrganizationName={cfg.get('OrganizationName')!r} SkipSetup has {len(sk)} panes, Restore {('SKIPPED' if 'Restore' in sk else 'shown')}"

def _cert_matches(cfg, keybag) -> bool | None:
    try:
        from cryptography import x509
        from cryptography.hazmat.primitives.serialization import Encoding
        der = x509.load_pem_x509_certificate(Path(keybag).read_bytes()).public_bytes(Encoding.DER)
        certs = [bytes(c) for c in cfg.get('SupervisorHostCertificates') or []]
        return der in certs
    except Exception:
        return None
RECONNECT_TIMEOUT = 480
ACTIVATION_WAIT = 300
SELF_ACTIVATE_GRACE = 45
ACTIVATE_RETRY_EVERY = 60
ACTIVATION_POLL = 5
ACTIVATION_LOCK_MSG = 'Activation Lock is on. The phone owner must unlock it with their Apple ID on the phone (or turn off Find My on their account). No password should be entered in this app. '
RECONNECT_SLEEP = 5

def _is_reconnectable(e: BaseException) -> bool:
    try:
        from pymobiledevice3 import exceptions as X
        kinds = tuple((k for k in (getattr(X, n, None) for n in ('DeviceNotFoundError', 'NoDeviceConnectedError', 'ConnectionFailedError', 'MuxException', 'ConnectionTerminatedError', 'NotConnectedError', 'InvalidConnectionError', 'BadDevError')) if k))
    except Exception:
        kinds = ()
    if kinds and isinstance(e, kinds):
        return True
    if isinstance(e, (ConnectionError, OSError, asyncio.IncompleteReadError, EOFError, asyncio.TimeoutError)):
        return True
    msg = str(e).lower()
    return 'device not found' in msg or 'no device' in msg or ('connection' in msg and ('refused' in msg or 'reset' in msg or 'closed' in msg))

def _mentions_activation_lock(e: BaseException) -> bool:
    msg = (type(e).__name__ + ' ' + str(e)).lower().replace('_', ' ')
    return 'activation lock' in msg or 'activationlock' in msg.replace(' ', '')
import json
import shutil
import sqlite3
import tempfile
from contextlib import closing
from datetime import datetime

class BackupError(SetupError):
    pass

class BackupPasswordError(BackupError):
    pass
GB = 1024 ** 3
BACKUP_HEADROOM = 2 * GB
RESTORE_SYSTEM_FILES = False
POST_RESTORE_RECONNECT = 900
RESTORE_SETTLE = 15
ERASE_SETTLE = 12
VERIFIED_MARKER = 'KosherGuard-verified.json'
FILTER_REPORT = 'KosherGuard-restore-filter.json'
FULL_MANIFEST = 'Manifest-full.db'
EXCLUDED_DOMAINS = ('SysSharedContainerDomain-systemgroup.com.apple.configurationprofiles', 'ManagedPreferencesDomain', 'SystemPreferencesDomain')
EXCLUDED_DOMAIN_RE = re.compile('configurationprofiles|managedconfiguration|mdmclient|\\.mdm(\\.|$)|devicemanagement', re.I)
EXCLUDED_PATH_RE = re.compile('(^|/)(ConfigurationProfiles|Managed Preferences)(/|$)|CloudConfigurationDetails|SharedDeviceConfiguration|(^|/)com\\.apple\\.(managedconfiguration|mdm|purplebuddy)[^/]*\\.plist$', re.I)
_SECRETS: set = set()

def add_secret(s: str) -> None:
    if s:
        _SECRETS.add(s)

def _redact(text: str) -> str:
    for s in _SECRETS:
        if s:
            text = text.replace(s, '***')
    return text

def is_excluded(domain: str, relative_path: str) -> bool:
    d = domain or ''
    p = relative_path or ''
    return d in EXCLUDED_DOMAINS or bool(EXCLUDED_DOMAIN_RE.search(d)) or bool(EXCLUDED_PATH_RE.search(p))

def backups_root() -> Path:
    if os.name == 'nt' and os.environ.get('APPDATA'):
        return Path(os.environ['APPDATA']) / 'KosherGuard' / 'backups'
    return Path(os.environ.get('KG_BACKUP_ROOT') or Path.home() / '.kosherguard' / 'backups')

def disk_free(path: Path) -> int | None:
    p = Path(path)
    while not p.exists() and p.parent != p:
        p = p.parent
    try:
        return shutil.disk_usage(p).free
    except Exception:
        return None

def human(n) -> str:
    if n is None:
        return 'unknown'
    return f'{n / GB:.1f} GB' if n >= GB / 10 else f'{n / 1024 ** 2:.0f} MB'

def space_check(used: int | None, free: int | None) -> tuple[str, str]:
    if free is None:
        return ('ok', 'Could not read the free space on this PC; the backup will stop safely if it runs out.')
    if used is None:
        return ('ok' if free >= 10 * GB else 'tight', f'This PC has {human(free)} free. (The phone did not report its used space.)')
    need = used + BACKUP_HEADROOM
    hard = int(used * 0.6) + BACKUP_HEADROOM
    base = f'The iPhone uses about {human(used)}. This PC has {human(free)} free.'
    if free < hard:
        return ('no', base + f' Not enough room for the backup. Free up at least {human(hard - free)} on this PC (or more), then try again. Nothing was changed.')
    if free < need:
        return ('tight', base + ' It may be tight; if the PC runs out of room the backup stops safely and nothing is erased.')
    return ('ok', base + ' Enough room for the backup.')

def new_backup_dir(udid: str) -> Path:
    base = backups_root() / f"{udid}-{datetime.now().strftime('%Y%m%d-%H%M%S')}"
    (p, n) = (base, 1)
    while p.exists():
        n += 1
        p = base.with_name(f'{base.name}-{n}')
    return p

def _device_dir(backup_dir: Path, udid: str | None=None) -> Path:
    backup_dir = Path(backup_dir)
    if udid and (backup_dir / udid).is_dir():
        return backup_dir / udid
    subs = [p for p in backup_dir.iterdir() if p.is_dir() and (p / 'Manifest.plist').exists()] if backup_dir.is_dir() else []
    if len(subs) != 1:
        raise BackupError(f'The backup folder {backup_dir} does not contain exactly one phone backup.')
    return subs[0]

def _read_manifest_plist(device_dir: Path) -> dict:
    p = device_dir / 'Manifest.plist'
    if not p.exists() or p.stat().st_size == 0:
        raise BackupError('The backup is incomplete: Manifest.plist is missing or empty.')
    try:
        return plistlib.loads(p.read_bytes())
    except Exception as e:
        raise BackupError('The backup is damaged: Manifest.plist cannot be read. ' + describe_error(e)) from e

def _decrypt_manifest_db(device_dir: Path, password: str, out: Path) -> bytes:
    if not password:
        raise BackupPasswordError("This backup is encrypted. Type the iPhone's backup password in the app.")
    from pymobiledevice3.services.mobilebackup2 import Mobilebackup2Service
    try:
        key = Mobilebackup2Service._decrypt_backup_manifest_db(device_dir, password, out)
        with closing(sqlite3.connect(str(out))) as c:
            c.execute('SELECT count(*) FROM Files').fetchone()
        return key
    except BackupPasswordError:
        raise
    except Exception as e:
        raise BackupPasswordError(f'The backup password did not work. Check it and type it again. ({type(e).__name__})') from e

def verify_backup(backup_dir: Path, udid: str | None=None, password: str='') -> dict:
    backup_dir = Path(backup_dir)
    dd = _device_dir(backup_dir, udid)
    for name in ('Info.plist', 'Manifest.plist', 'Manifest.db', 'Status.plist'):
        f = dd / name
        if not f.exists() or f.stat().st_size == 0:
            raise BackupError(f'The backup is incomplete: {name} is missing or empty.')
    try:
        status = plistlib.loads((dd / 'Status.plist').read_bytes())
    except Exception as e:
        raise BackupError('The backup is damaged: Status.plist cannot be read. ' + describe_error(e)) from e
    if status.get('SnapshotState') != 'finished':
        raise BackupError(f"The backup did not finish (Status.plist SnapshotState={status.get('SnapshotState')!r}).")
    manifest = _read_manifest_plist(dd)
    encrypted = bool(manifest.get('IsEncrypted', False))
    with tempfile.TemporaryDirectory() as td:
        db = dd / 'Manifest.db'
        if encrypted:
            db = Path(td) / 'Manifest.sqlite'
            _decrypt_manifest_db(dd, password, db)
        try:
            with closing(sqlite3.connect(str(db))) as c:
                rows = c.execute('SELECT fileID, domain, flags FROM Files').fetchall()
        except BackupError:
            raise
        except Exception as e:
            raise BackupError('The backup is damaged: Manifest.db cannot be read. ' + describe_error(e)) from e
    files = [r for r in rows if r[2] == 1]
    domains = {r[1] for r in rows}
    if not files or 'HomeDomain' not in domains:
        raise BackupError(f'The backup looks empty ({len(rows)} entries, {len(files)} files). It was not accepted.')
    missing = [fid for (fid, _, _) in files if not (dd / fid[:2] / fid).is_file()]
    allowed = 0
    if len(missing) > allowed:
        raise BackupError(f'The backup is incomplete: {len(missing)} of {len(files)} files are missing on this PC.')
    size = 0
    for p in dd.rglob('*'):
        try:
            if p.is_file():
                size += p.stat().st_size
        except OSError:
            pass
    info = {'udid': dd.name, 'folder': str(backup_dir), 'entries': len(rows), 'files': len(files), 'domains': len(domains), 'missing': len(missing), 'size': size, 'encrypted': encrypted, 'date': str(status.get('Date', '')), 'verified_at': datetime.now().isoformat(timespec='seconds')}
    (backup_dir / VERIFIED_MARKER).write_text(json.dumps(info, indent=1), encoding='utf-8')
    log(f'verify_backup OK: {info}')
    return info

def find_backups(udid: str) -> list:
    out = []
    root = backups_root()
    if not root.is_dir():
        return out
    for d in root.iterdir():
        m = d / VERIFIED_MARKER
        if d.is_dir() and d.name.startswith(udid + '-') and m.exists():
            try:
                info = json.loads(m.read_text(encoding='utf-8'))
                info['folder'] = str(d)
                out.append(info)
            except Exception:
                pass
    return sorted(out, key=lambda i: i.get('verified_at', ''), reverse=True)

def _prune(db: Path) -> dict:
    removed = {}
    with closing(sqlite3.connect(str(db))) as c:
        rows = c.execute('SELECT fileID, domain, relativePath FROM Files').fetchall()
        drop = [(fid,) for (fid, d, p) in rows if is_excluded(d, p)]
        for (fid, d, p) in rows:
            if is_excluded(d, p):
                removed[d] = removed.get(d, 0) + 1
        if drop:
            c.executemany('DELETE FROM Files WHERE fileID = ?', drop)
        c.commit()
    return {'total': len(rows), 'removed': sum(removed.values()), 'kept': len(rows) - sum(removed.values()), 'removed_domains': removed}

def filter_backup_for_restore(backup_dir: Path, udid: str | None=None, password: str='') -> dict:
    dd = _device_dir(Path(backup_dir), udid)
    full = dd / FULL_MANIFEST
    live = dd / 'Manifest.db'
    if not full.exists():
        shutil.copy2(live, full)
    shutil.copy2(full, live)
    encrypted = bool(_read_manifest_plist(dd).get('IsEncrypted', False))
    if not encrypted:
        stats = _prune(live)
    else:
        from pymobiledevice3.services.mobilebackup2 import Mobilebackup2Service
        with tempfile.TemporaryDirectory() as td:
            dec = Path(td) / 'Manifest.sqlite'
            key = _decrypt_manifest_db(dd, password, dec)
            stats = _prune(dec)
            Mobilebackup2Service._encrypt_backup_manifest_db(dec, live, key)
    stats['encrypted'] = encrypted
    (Path(backup_dir) / FILTER_REPORT).write_text(json.dumps(stats, indent=1), encoding='utf-8')
    log(f'filter_backup_for_restore: {stats}')
    return stats

def _pct_reporter(progress, label: str):
    last = {'p': -1}

    def cb(p):
        try:
            v = max(0.0, min(100.0, float(p)))
        except Exception:
            return
        if int(v) != last['p']:
            last['p'] = int(v)
            progress(f'{label} {int(v)}%', v)
    return cb

def _short(x, n=60):
    try:
        t = repr(x)
    except Exception:
        t = '?'
    return t if len(t) <= n else t[:n] + '...'

def kg_profiles_from_list(pl) -> list:
    out = []
    meta = (pl or {}).get('ProfileMetadata', {}) if isinstance(pl, dict) else {}
    for (ident, m) in (meta or {}).items():
        m = m if isinstance(m, dict) else {}
        nm = str(m.get('PayloadDisplayName', '') or '')
        if 'kosherguard' not in (str(ident) + ' ' + nm).lower():
            continue
        mt = re.fullmatch('com\\.kosherguard\\.device\\.kg([a-z0-9]{6})', str(ident), re.I)
        out.append({'identifier': str(ident), 'device_id': 'KG-' + mt.group(1).upper() if mt else '', 'name': nm[:80], 'version': m.get('PayloadVersion'), 'uuid': str(m.get('PayloadUUID', '') or '')[:40]})
    return out

async def decide_supervision(client, v, MobileConfigService, extra=None):
    parts = []
    lock = None
    if isinstance(v, dict) and 'IsSupervised' in v:
        lock = bool(v.get('IsSupervised'))
        parts.append('lockdown all_values=' + str(lock))
    else:
        parts.append('lockdown all_values=missing')
    try:
        gv = await client.get_value(key='IsSupervised')
        if gv is None:
            parts.append('get_value=None')
        else:
            gvb = bool(gv)
            parts.append('get_value=' + str(gvb))
            lock = True if gvb or lock else False if lock is None else lock
    except Exception as e:
        parts.append('get_value error ' + type(e).__name__)
    cloud = None
    cloud_read = False
    try:
        async with MobileConfigService(client) as service:
            cfg = await service.get_cloud_configuration()
        cloud_read = True
        if isinstance(cfg, dict):
            cloud = cfg.get('IsSupervised')
            parts.append('cloud IsSupervised=' + _short(cloud) + ' org=' + _short(cfg.get('OrganizationName'), 30))
        else:
            parts.append('cloud config=' + _short(cfg))
    except Exception as e:
        parts.append('cloud config error ' + type(e).__name__)
    kg_profile = False
    prof_read = False
    try:
        async with MobileConfigService(client) as service:
            pl = await service.get_profile_list()
        prof_read = True
        meta = (pl or {}).get('ProfileMetadata', {}) if isinstance(pl, dict) else {}
        names = []
        for (ident, m) in (meta or {}).items():
            nm = (m or {}).get('PayloadDisplayName', '') if isinstance(m, dict) else ''
            names.append(str(ident))
            if 'kosherguard' in (str(ident) + ' ' + str(nm)).lower():
                kg_profile = True
        parts.append('profiles=' + str(len(names)) + (' (KosherGuard profile present)' if kg_profile else ''))
        if extra is not None:
            extra['kg_profiles'] = kg_profiles_from_list(pl)
    except Exception as e:
        parts.append('profile list error ' + type(e).__name__)
    if lock is True or cloud is True:
        result = True
    elif lock is False or lock is None:
        if cloud_read and cloud is not True and prof_read and (not kg_profile):
            result = False
        else:
            result = None
    else:
        result = None
    detail = '; '.join(parts) + ' => ' + {True: 'YES', False: 'NO', None: 'UNKNOWN'}[result]
    return (result, detail)

class RealDevice:

    def __init__(self):
        self.serial = None
        self.client = None
        self.keybag = None
        self.restore_flow = False

    async def find(self) -> dict:
        from pymobiledevice3.usbmux import list_devices
        try:
            devices = [d for d in await list_devices() if d.is_usb]
        except Exception as e:
            raise SetupError(f'USB driver not reachable. Install Apple Devices (or iTunes) and reconnect. ' + error_detail(e)) from e
        if len(devices) != 1:
            raise SetupError('Connect exactly one iPhone by USB. Found ' + str(len(devices)) + ' USB Apple devices.')
        self.serial = devices[0].serial
        return await self.connect()

    def hw_from(self, v) -> dict:
        self.hw = {'serial': v.get('SerialNumber') or '', 'udid': v.get('UniqueDeviceID') or self.serial or '', 'product': v.get('ProductType') or '', 'build': v.get('BuildVersion') or ''}
        return dict(self.hw)

    async def connect(self) -> dict:
        if not self.serial:
            raise SetupError('No phone selected.')
        from pymobiledevice3.lockdown import create_using_usbmux
        try:
            self.client = await create_using_usbmux(serial=self.serial, connection_type='USB', pair_timeout=75)
            v = self.client.all_values
            if v.get('DeviceClass') != 'iPhone':
                raise SetupError('Connected device is ' + str(v.get('DeviceClass', 'unknown')) + ', not an iPhone.')
            (supervised, sup_detail) = await self.supervision_status(v)
            log('Supervised check: ' + sup_detail)
            try:
                disp = self.client.display_name
            except Exception:
                disp = None
            return {'name': v.get('DeviceName') or disp or 'iPhone', 'model': disp or v.get('ProductType', 'iPhone'), 'ios': self.client.product_version, 'supervised': supervised, 'supervised_detail': sup_detail, 'kg_profiles': list(getattr(self, 'kg_profiles', []) or []), 'activated': v.get('ActivationState') == 'Activated', 'serial': self.serial, 'hw': self.hw_from(v)}
        except SetupError:
            raise
        except Exception as e:
            raise SetupError(f'Could not talk to the iPhone. Unlock it and tap Trust on its screen. ' + error_detail(e)) from e

    async def erase_and_reconnect(self, progress):
        from pymobiledevice3.services.mobile_config import MobileConfigService
        from pymobiledevice3.usbmux import wait_for_device_detach
        progress('Sending erase command. DO NOT unplug the phone.')
        try:
            async with MobileConfigService(self.client) as service:
                await service.erase_device(preserve_data_plan=True, disallow_proximity_setup=False)
        except Exception as e:
            raise SetupError(f'Erase did not complete. Check Find My and the phone screen. Do not assume anything was erased. ' + error_detail(e)) from e
        await self.close()
        progress('Waiting for the phone to reboot to Hello / Setup Assistant. Keep USB connected (up to 10 minutes).')
        try:
            await wait_for_device_detach(self.serial, timeout=90)
        except Exception:
            pass
        await asyncio.sleep(ERASE_SETTLE)
        deadline = time.monotonic() + RECONNECT_TIMEOUT
        while True:
            await self.reconnect_verified(progress, timeout=max(30, deadline - time.monotonic()))
            try:
                return await self.connect()
            except SetupError as e:
                if e.__cause__ is not None and _is_reconnectable(e.__cause__) and (time.monotonic() < deadline):
                    await asyncio.sleep(RECONNECT_SLEEP)
                    continue
                raise

    async def reconnect_verified(self, progress=None, timeout: float=None):
        from pymobiledevice3.lockdown import create_using_usbmux
        timeout = RECONNECT_TIMEOUT if timeout is None else timeout
        deadline = time.monotonic() + timeout
        last = None
        told = False
        n = 0
        while True:
            n += 1
            await self.close()
            self.client = None
            try:
                self.client = await create_using_usbmux(serial=self.serial, connection_type='USB', pair_timeout=60)
                ver = await self.client.get_value(key='ProductVersion')
                if not ver:
                    raise ConnectionError('phone answered without a ProductVersion')
                return self.client
            except Exception as e:
                if type(e).__name__ == 'UserDeniedPairingError':
                    raise SetupError(f"""The iPhone refused this computer ("Don't Trust"). Unplug, replug, tap Trust, then rerun this app. Do not erase again. """ + error_detail(e)) from e
                last = e
            if time.monotonic() >= deadline:
                await self.close()
                self.client = None
                raise SetupError('The phone did not come back over USB within ~8 minutes. Leave it on the Hello screen, unplug and replug the cable, then rerun this app and click Find my iPhone. Do not erase again. ' + (error_detail(last) if last is not None else 'Detail: no error recorded.'))
            if progress and (not told):
                progress('Phone is still restarting. Waiting for it to come back over USB (up to ~8 minutes)...')
                told = True
            await asyncio.sleep(RECONNECT_SLEEP)

    async def _is_supervised(self) -> bool:
        from pymobiledevice3.services.mobile_config import MobileConfigService
        try:
            if bool(await self.client.get_value(key='IsSupervised')):
                return True
        except Exception:
            pass
        try:
            async with MobileConfigService(self.client) as service:
                cfg = await service.get_cloud_configuration()
            return isinstance(cfg, dict) and cfg.get('IsSupervised') is True
        except Exception:
            return False

    async def supervision_status(self, v=None):
        from pymobiledevice3.services.mobile_config import MobileConfigService
        self.kg_profiles = []
        extra = {}
        r = await decide_supervision(self.client, v if v is not None else getattr(self.client, 'all_values', None) or {}, MobileConfigService, extra)
        self.kg_profiles = extra.get('kg_profiles') or []
        return r

    async def activate_robust(self, progress):
        from pymobiledevice3.services.mobile_activation import MobileActivationService
        start = time.monotonic()
        deadline = start + ACTIVATION_WAIT
        first_unact = None
        last_try = None
        tries = 0
        last_err = None
        told = False
        while True:
            now = time.monotonic()
            state = None
            try:
                state = await MobileActivationService(self.client).state()
            except Exception as e:
                if _mentions_activation_lock(e):
                    raise SetupError(ACTIVATION_LOCK_MSG + error_detail(e)) from e
                last_err = e
                log('activation state not readable yet: ' + describe_error(e))
                if _is_reconnectable(e) and now < deadline:
                    progress('Lost the USB connection to the phone (it may still be restarting). Reconnecting...')
                    await self.reconnect_verified(progress, timeout=max(30, deadline - now))
                    continue
            if state is not None and state != 'Unactivated':
                log(f'activation state: {state!r} after {now - start:.0f}s ({tries} activate calls)')
                if tries or told:
                    progress('The iPhone is activated.')
                return state
            if state == 'Unactivated':
                first_unact = first_unact if first_unact is not None else now
                if now - first_unact >= SELF_ACTIVATE_GRACE and (last_try is None or now - last_try >= ACTIVATE_RETRY_EVERY):
                    last_try = now
                    tries += 1
                    progress(f'Activating with Apple (try {tries}). The computer needs internet...')
                    try:
                        await MobileActivationService(self.client).activate(skip_apple_id_query=True)
                        log(f'activate() try {tries} returned')
                        continue
                    except Exception as e:
                        if _mentions_activation_lock(e):
                            raise SetupError(ACTIVATION_LOCK_MSG + error_detail(e)) from e
                        last_err = e
                        log(f'activate() try {tries} not ready: ' + describe_error(e), e)
                        if _is_reconnectable(e) and now < deadline:
                            await self.reconnect_verified(progress, timeout=max(30, deadline - now))
                            continue
            if now >= deadline:
                raise SetupError('The iPhone did not finish activating within about 5 minutes. Leave it on the Hello screen, make sure it can reach Wi-Fi or cellular, then click "Check the connected phone again" (no second erase is needed). ' + (error_detail(last_err) if last_err else f'Last state: {state!r}.'))
            if not told:
                progress('Waiting for the iPhone to activate itself (newer iPhones do this on the Hello screen). Up to ~5 minutes...')
                told = True
            await asyncio.sleep(ACTIVATION_POLL)

    async def activate_and_supervise(self, progress, show_restore: bool=False, mdm: dict | None=None):
        from pymobiledevice3.services.mobile_config import MobileConfigService
        from pymobiledevice3.services.mobile_activation import MobileActivationService
        self.keybag = get_identity()
        await self.activate_robust(progress)
        deadline = time.monotonic() + RECONNECT_TIMEOUT
        progress('Applying supervised mode (organization: KosherGuard)' + (', with the Restore screen shown' if show_restore else '') + '...')
        self.restore_flow = bool(show_restore)
        self.restore_skipped_by_existing = False
        log(f'activate_and_supervise: show_restore={show_restore}')

        async def read_cloud():
            try:
                async with MobileConfigService(self.client) as service:
                    cfg = await service.get_cloud_configuration()
                log('get_cloud_configuration: ' + summarize_cloud(cfg))
                return cfg
            except Exception as e:
                log('get_cloud_configuration failed: ' + describe_error(e), e)
                if _is_reconnectable(e):
                    raise
                return None

        def ours(cfg) -> bool:
            return isinstance(cfg, dict) and cfg.get('IsSupervised') is True

        def accept_existing(cfg, why):
            sk = cfg.get('SkipSetup') or []
            restore_skipped = 'Restore' in sk
            self.restore_skipped_by_existing = bool(show_restore and restore_skipped)
            org = cfg.get('OrganizationName')
            m = _cert_matches(cfg, self.keybag)
            progress(f"{why}: already supervised by {org} (Restore screen {('skipped' if restore_skipped else 'will be shown')}; this PC's supervision identity {('matches' if m else 'does NOT match' if m is False else 'could not be compared')}).")
            log(f'{why}: accepted existing config; {summarize_cloud(cfg)}; cert_matches={m}')
            if org != ORG:
                progress(f'Note: the organization on the phone is "{org}", not "{ORG}".')
            if self.restore_skipped_by_existing:
                progress(SKIPPED_RESTORE_MSG)
        done = False
        while True:
            try:
                cfg = await read_cloud()
                break
            except Exception as e:
                if time.monotonic() < deadline:
                    progress('Lost the USB connection to the phone. Reconnecting...')
                    await self.reconnect_verified(progress, timeout=max(30, deadline - time.monotonic()))
                    continue
                cfg = None
                break
        if ours(cfg) and cfg.get('OrganizationName') == ORG:
            if mdm:
                raise CloudConfigError('A cloud setup already exists. This TEST cannot replace it; do not erase again automatically.')
            accept_existing(cfg, 'Checked the phone')
            done = True
        while not done:
            try:
                async with MobileConfigService(self.client) as service:
                    await service.set_cloud_configuration(cloud_configuration(ORG, self.keybag, show_restore=show_restore, mdm=mdm))
                log('set_cloud_configuration: acknowledged')
                done = True
            except Exception as e:
                log('set_cloud_configuration raised: ' + describe_error(e), e)
                if _is_reconnectable(e) and time.monotonic() < deadline:
                    progress('Lost the USB connection to the phone. Reconnecting...')
                    await self.reconnect_verified(progress, timeout=max(30, deadline - time.monotonic()))
                    continue
                first_err = e
                try:
                    cfg = await read_cloud()
                except Exception:
                    cfg = None
                if mdm:
                    if ours(cfg) and cfg.get('ConfigurationURL') == mdm['url']:
                        progress('The iPhone reports the TEST configuration was applied despite the USB interruption.')
                        done = True
                        break
                    raise CloudConfigError('iPhone refused the TEST setup settings. No normal supervision fallback was used. If the phone cannot leave Setup Assistant, use Apple Devices on Windows to restore it. ' + _redact(describe_error(first_err))) from first_err
                if ours(cfg):
                    accept_existing(cfg, 'The phone refused a second setup')
                    done = True
                    break
                progress(f'The phone refused the supervision settings ({type(e).__name__}). Trying the standard method once...')
                log('fallback: MobileConfigService.supervise(ORG, keybag)')
                try:
                    async with MobileConfigService(self.client) as service:
                        await service.supervise(ORG, self.keybag)
                    log('fallback supervise(): acknowledged')
                    if show_restore:
                        self.restore_skipped_by_existing = True
                        progress('Supervised with the standard method. ' + SKIPPED_RESTORE_MSG.replace('because an earlier run already set up the phone without it', 'because the standard method skips it'))
                    done = True
                    break
                except Exception as e2:
                    log('fallback supervise() raised: ' + describe_error(e2), e2)
                    try:
                        cfg = await read_cloud()
                    except Exception:
                        cfg = None
                    if ours(cfg):
                        accept_existing(cfg, 'After the standard method')
                        done = True
                        break
                    raise CloudConfigError(f'Supervision was not applied. Leave the phone connected. Do not erase it again; inspect its screen, then rerun this app. First try: {describe_error(first_err)}. Standard method: {describe_error(e2)}. Phone now reports: {summarize_cloud(cfg)}. Full log: {log_path()}') from e2
        verified = await self._is_supervised()
        if not verified:
            raise SetupError('The phone did not report supervised mode yet. Check Settings > General > About. This app will not install the locked profile without confirmation.')
        progress('Supervised mode confirmed. Keep the supervision identity safe.')
        return self.keybag

    async def preflight(self) -> dict:
        udid = getattr(self.client, 'udid', None) or self.serial
        used = None
        try:
            du = await self.client.get_value(domain='com.apple.disk_usage')
            if isinstance(du, dict):
                total = du.get('TotalDataCapacity') or du.get('TotalDiskCapacity')
                avail = du.get('TotalDataAvailable') if du.get('TotalDataAvailable') is not None else du.get('AmountDataAvailable')
                if total and avail is not None:
                    used = max(0, int(total) - int(avail))
        except Exception as e:
            log('disk usage not readable: ' + describe_error(e))
        enc = False
        try:
            enc = bool(await self.client.get_value(domain='com.apple.mobile.backup', key='WillEncrypt'))
        except Exception as e:
            log('WillEncrypt not readable: ' + describe_error(e))
        setup_done = None
        for dom in ('com.apple.PurpleBuddy', 'com.apple.purplebuddy'):
            try:
                d = await self.client.get_value(domain=dom)
            except Exception:
                continue
            if isinstance(d, dict):
                if d.get('SetupDone') is True or d.get('SetupFinishedAllSteps') is True:
                    setup_done = True
                elif setup_done is None and d.get('SetupDone') is False:
                    setup_done = False
        root = backups_root()
        free = await asyncio.to_thread(disk_free, root)
        (verdict, msg) = space_check(used, free)
        try:
            backups = await asyncio.to_thread(find_backups, udid) if udid else []
        except Exception:
            backups = []
        pf = {'udid': udid, 'used': used, 'free': free, 'space': verdict, 'space_msg': msg, 'encrypted': enc, 'setup_done': setup_done, 'root': str(root), 'backups': backups}
        log(f"preflight: { {k: v for (k, v) in pf.items() if k != 'backups'}} backups={len(backups)}")
        return pf

    async def backup_to_pc(self, progress, password: str='') -> dict:
        from pymobiledevice3.services.mobilebackup2 import Mobilebackup2Service
        add_secret(password)
        udid = getattr(self.client, 'udid', None) or self.serial
        bdir = new_backup_dir(udid)
        bdir.mkdir(parents=True, exist_ok=False)
        log(f'backup_to_pc: into {bdir}')
        progress('Backing up the iPhone to this PC. Keep the cable plugged in. If the iPhone asks for its passcode, type it on the iPhone.', 0)
        try:
            async with Mobilebackup2Service(self.client) as mb:
                await mb.backup(full=True, backup_directory=str(bdir), progress_callback=_pct_reporter(progress, 'Backing up the iPhone to this PC...'))
        except Exception as e:
            log('backup failed: ' + describe_error(e), e)
            await asyncio.to_thread(shutil.rmtree, bdir, True)
            raise BackupError('The backup did not finish, so the iPhone was NOT erased. Nothing on the phone changed. Keep it unlocked and plugged in, then try again. ' + error_detail(e)) from e
        progress('Checking the backup (every file)...', 100)
        try:
            info = await asyncio.to_thread(verify_backup, bdir, udid, password)
        except BackupPasswordError as e:
            e.backup_dir = str(bdir)
            raise
        except BackupError as e:
            log('backup did not verify: ' + str(e), e)
            await asyncio.to_thread(shutil.rmtree, bdir, True)
            raise BackupError(str(e) + ' The iPhone was NOT erased. Nothing on the phone changed.') from e
        progress(f"Backup checked: {info['files']} files, {human(info['size'])}.")
        return info

    async def restore_from_pc(self, backup_dir, progress, password: str='') -> dict:
        from pymobiledevice3.services.mobilebackup2 import Mobilebackup2Service
        from pymobiledevice3.usbmux import wait_for_device_detach
        add_secret(password)
        backup_dir = Path(backup_dir)
        dd = await asyncio.to_thread(_device_dir, backup_dir, None)
        source = dd.name
        manifest = await asyncio.to_thread(_read_manifest_plist, dd)
        if manifest.get('IsEncrypted') and (not password):
            raise BackupPasswordError("This backup is encrypted. Type the iPhone's backup password in the app.")
        progress('Preparing your backup: leaving out the settings and management files that would undo supervision...')
        # Preserve the original manifest even if filtering or restore raises.
        live = dd / 'Manifest.db'
        full = dd / FULL_MANIFEST
        if not full.exists():
            await asyncio.to_thread(shutil.copy2, live, full)
        try:
            stats = await asyncio.to_thread(filter_backup_for_restore, backup_dir, source, password)
            progress(f"Putting your data back: {stats['kept']} items ({stats['removed']} settings/management items left out). Keep the cable plugged in.", 0)
            log(f'restore: source={source} system={RESTORE_SYSTEM_FILES} reboot=True copy=False settings(preserve)=True remove=False')
            async with Mobilebackup2Service(self.client) as mb:
                await mb.restore(backup_directory=str(backup_dir), system=RESTORE_SYSTEM_FILES, reboot=True, copy=False, settings=True, remove=False, password=password, source=source, progress_callback=_pct_reporter(progress, 'Putting your data back...'))
        except Exception as e:
            log('restore failed: ' + describe_error(e), e)
            raise SetupError('Putting the backup back did not finish. Your backup is retained on this PC at ' + str(backup_dir) + '. Leave the iPhone plugged in and click "Check the connected phone again" to try again. ' + error_detail(e)) from e
        finally:
            await asyncio.to_thread(shutil.copy2, full, live)
        await self.close()
        progress('Data sent. The iPhone is restarting to finish (this can take several minutes). Keep it plugged in. If it asks "Trust This Computer?", tap Trust.')
        try:
            await wait_for_device_detach(self.serial, timeout=120)
        except Exception:
            pass
        await asyncio.sleep(RESTORE_SETTLE)
        await self.reconnect_verified(progress, timeout=POST_RESTORE_RECONNECT)
        return stats

    async def ensure_supervised(self, progress, mdm: dict | None=None) -> str:
        from pymobiledevice3.services.mobile_config import MobileConfigService
        self.restore_flow = True
        progress('Checking that the iPhone is still supervised after the restore...')
        if await self._is_supervised():
            progress('Still supervised after the restore.')
            return 'kept'
        raise SetupError(RESTORE_LOST_MSG + RESTORE_LOST_HELP)

    async def setup_state(self) -> dict:
        from pymobiledevice3.lockdown import create_using_usbmux
        from pymobiledevice3.usbmux import list_devices
        from pymobiledevice3.services.mobile_config import MobileConfigService
        st = {'connected': False, 'setup_done': None, 'others': [], 'kg': [], 'supervised': None, 'error': ''}
        try:
            if self.client is None:
                usb = [d for d in await asyncio.wait_for(list_devices(), 15) if d.is_usb]
                if self.serial and (not any((d.serial == self.serial for d in usb))):
                    st['error'] = 'not on USB'
                    return st
                if not self.serial:
                    if len(usb) != 1:
                        st['error'] = f'{len(usb)} USB devices'
                        return st
                    self.serial = usb[0].serial
                self.client = await asyncio.wait_for(create_using_usbmux(serial=self.serial, connection_type='USB', pair_timeout=20), 45)
            done = None
            for dom in ('com.apple.PurpleBuddy', 'com.apple.purplebuddy'):
                try:
                    d = await asyncio.wait_for(self.client.get_value(domain=dom), 15)
                except Exception:
                    continue
                if isinstance(d, dict):
                    if d.get('SetupDone') is True or d.get('SetupFinishedAllSteps') is True:
                        done = True
                    elif done is None and d.get('SetupDone') is False:
                        done = False
            st['setup_done'] = done
            try:
                st['supervised'] = bool(await asyncio.wait_for(self.client.get_value(key='IsSupervised'), 15))
            except Exception:
                pass
            st['connected'] = True
            try:
                async with MobileConfigService(self.client) as service:
                    pl = await asyncio.wait_for(service.get_profile_list(), 20)
                for (ident, meta) in (pl.get('ProfileMetadata') or {}).items():
                    if str(ident).startswith('com.kosherguard.'):
                        st['kg'].append(str(ident))
                    else:
                        st['others'].append(str((meta or {}).get('PayloadDisplayName') or ident))
            except Exception as e:
                st['error'] = 'profile list: ' + describe_error(e)
        except Exception as e:
            st['error'] = describe_error(e)
            await self.close()
        return st

    async def close(self):
        if self.client:
            try:
                await self.client.close()
            except Exception:
                pass
            self.client = None
NOT_SUPERVISED_AFTER_RESTORE = 'Your data was put back, but the iPhone is NOT supervised any more, so the filter was NOT installed and NOT locked. This app will not pretend otherwise.'
PARTIAL_SETUP_TIP = 'If the iPhone says “iPhone Partially Set Up”, tap “Continue with Partial Setup” (the small blue text). Do NOT tap “Erase and Start Over”.'
