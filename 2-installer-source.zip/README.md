# KosherGuard desktop setup, spare-phone test build

Python/Tkinter iPhone-only app, adapted visually and in USB backup routines from the owner's v5.6.2 source. Uses admin.kosherguard.xyz and mdm.kosherguard.xyz. No third-party MDM or Android flows.

This ZIP is SOURCE plus Windows packaging commands, NOT an already-built .exe. No Windows runner was available for this delivery. It is not a replacement for the currently hosted installer. Do not treat Linux mock tests as a real Windows/USB test.

## Windows
Install Python 3.12 with Tcl/Tk and launcher, then run build-windows.cmd. It downloads free dependencies and creates dist/KosherGuard-Setup.exe. Packaging command is supplied, but has not been run on Windows. No signing certificate is included; Windows may warn about an unsigned executable. Do not pay for any build service. Apple Devices from Microsoft Store supplies the USB driver.

For safe visual preview: py -3.12 -m pip install requests, then run run-preview.cmd. Preview never uses USB or network. For source execution install requirements.txt first. Do not run live setup until reviewed with your helper.

## Real work and limits
Discovery reads one USB iPhone only. The user must approve the detected phone in the existing dashboard before work starts. First-time supervision requires owner consent, Find My off, an independent usable backup and typing ERASE. The selected phone is re-read before destructive work. Unknown supervision stops setup. Already supervised phones require this PC's matching supervision identity.

The existing supervision identity lives under %APPDATA%\KosherGuard\supervision-identity.pem. Back it up privately. Do not replace it to take over an already supervised phone. If the old PowerShell installer has already created a different identity beside its script, restore/copy that SAME identity to this location before managing those phones. This new ZIP includes no identity, password, token or live enrollment profile.

The enrollment profile is downloaded from the currently shipped installer URL, checked for the own-MDM endpoints, then installed using the supervision identity. A server ProfileList verification must confirm the enrollment lock before the result says management verified. iOS can reject cloud-configuration writes. A timeout does not prove failure or success. This installer does not prove that the website filter is active and does not add a DNS or VPN payload itself.

Backups are local. Integrity checks require all manifest-listed files, but cannot prove a successful restore. Restore intentionally excludes management and selected system settings and is NOT an identical restore. A full manifest copy is retained, and the original manifest is restored after the restore attempt. Keep an independent backup. No eSIM preservation guarantee; the USB erase requests preservation, but real carrier/device checks remain necessary.

Interrupted setup saves a local phase and backup folder, not the dashboard secret or backup password. Resume is offered only for the same phone on confirmed setup screens with a saved backup. It never sends another erase. If state is unclear, stop and inspect instead of guessing. The app may need the phone unlocked or setup completed before enrollment; a rejected operation stops with a clear message.

Before use with customers: native Windows layout/build test, dependency import and packaging test, then a spare-phone backup/erase/restore/enrollment/removal test. No physical phone was touched during development.

## Tests
python -m unittest discover -s tests -v
Screenshots use --preview with sample state. They are UI previews, not evidence of real enrollment.
