"""Own-MDM setup, called only after explicit GUI approval. No work runs on import."""
import asyncio, json, os, plistlib, webbrowser
from pathlib import Path
import requests
import usb_engine as usb

BASE = 'https://admin.kosherguard.xyz'
IDENT = 'com.mdm.enroll'
STEPS = ['Check setup approval', 'Check backup', 'Erase if needed', 'Supervise', 'Restore if chosen', 'Enroll in KosherGuard', 'Verify management']

class Pending(usb.SetupError): pass

def bundled_profile():
    # Fetch the currently shipped enrollment profile, never bundle its live SCEP challenge.
    import io, zipfile
    r=requests.get(BASE+'/d/daac78f0c49a7ccfecd797a4ef1cebfb/MDM-Windows-Installer.zip',timeout=30,allow_redirects=False)
    if not r.ok or len(r.content)>2000000: raise usb.SetupError('Could not read the current enrollment package. Nothing was erased.')
    with zipfile.ZipFile(io.BytesIO(r.content)) as z:
        data=z.read('MDM-Windows-Installer/enroll.mobileconfig')
    p = plistlib.loads(data)
    kinds = {x.get('PayloadType'): x for x in p.get('PayloadContent', [])}
    mdm = kinds.get('com.apple.mdm', {})
    if p.get('PayloadIdentifier') != IDENT or p.get('PayloadRemovalDisallowed') is not True:
        raise usb.SetupError('Enrollment profile is not the expected locked KosherGuard profile.')
    if mdm.get('ServerURL') != 'https://mdm.kosherguard.xyz/mdm' or mdm.get('CheckInURL') != 'https://mdm.kosherguard.xyz/checkin':
        raise usb.SetupError('Enrollment profile points to an unexpected management service.')
    if kinds.get('com.apple.security.scep',{}).get('PayloadContent',{}).get('URL') != 'https://mdm.kosherguard.xyz/scep':
        raise usb.SetupError('Enrollment profile is missing the device identity payload.')
    return data

def state_path():
    return usb.identity_path().parent / 'desktop-session.json'

def save_state(data):
    p = state_path(); p.parent.mkdir(parents=True, exist_ok=True)
    # No approval token, poll secret, backup password or key material is persisted here.
    p.write_text(json.dumps(data, indent=2));
    if os.name != 'nt': p.chmod(0o600)

def load_state():
    try: return json.loads(state_path().read_text())
    except (OSError, ValueError): return {}

class Service:
    def __init__(self, session=None): self.session = session or requests.Session()
    def call(self, path, data=None, secret=None):
        headers = {'X-Setup-Secret': secret} if secret else {}
        r = self.session.request('POST' if data is not None else 'GET', BASE+path, json=data, headers=headers, timeout=25, allow_redirects=False)
        if not r.ok: raise usb.SetupError('KosherGuard setup request failed (HTTP %d). No new erase will be started. Open the dashboard and retry.' % r.status_code)
        j = r.json()
        if not isinstance(j, dict): raise usb.SetupError('KosherGuard returned an unexpected reply.')
        return j
    async def approve(self, info, name, phone, progress):
        j = await asyncio.to_thread(self.call, '/api/setup/start', {'udid':info['serial'], 'name':name, 'phone':phone})
        token, secret, url = j['token'], j['pollSecret'], j['approvalUrl']
        from urllib.parse import urlparse
        u=urlparse(url)
        if u.scheme!='https' or u.netloc!='admin.kosherguard.xyz': raise usb.SetupError('Unexpected dashboard approval address.')
        usb.add_secret(token); usb.add_secret(secret); usb.add_secret(url)
        webbrowser.open(url)
        progress('Approve this detected phone in the dashboard. Setup has not erased anything.')
        for _ in range(300):
            r=await asyncio.to_thread(self.call, '/api/setup/'+token+'/poll', None, secret)
            if r.get('status')=='approved': return {'token':token,'secret':secret,'device_id':r.get('deviceId')}
            if r.get('status') in ('denied','expired'): raise usb.SetupError('Dashboard approval was declined or expired. Nothing was erased.')
            await asyncio.sleep(3)
        raise Pending('Dashboard approval timed out. No erase was started.')
    async def verify(self, grant, progress):
        for _ in range(60):
            r=await asyncio.to_thread(self.call, '/api/setup/'+grant['token']+'/verify', {}, grant['secret'])
            if r.get('status')=='verified': return True
            if r.get('status')=='failed': raise usb.SetupError('Enrollment was not confirmed as non-removable. Do not assume management is locked.')
            progress('Waiting for the phone to check in and confirm its enrollment profile.')
            await asyncio.sleep(3)
        raise Pending('Management verification is still pending. The profile may be installed. Check the dashboard before retrying; do not erase again.')

async def enroll(dev, data, progress):
    from pymobiledevice3.services.mobile_config import MobileConfigService
    if not await dev._is_supervised(): raise usb.SetupError('Supervision could not be confirmed. Enrollment stopped.')
    key=usb.get_identity()
    async with MobileConfigService(dev.client) as mc:
        cfg=await mc.get_cloud_configuration()
        if not isinstance(cfg,dict) or cfg.get('IsSupervised') is not True: raise usb.SetupError('Phone did not confirm supervised configuration.')
        if usb._cert_matches(cfg,key) is not True: raise usb.SetupError('This PC does not hold the matching supervision identity. No erase or takeover will be attempted.')
        cfg['IsMDMUnremovable']=True
        await mc.set_cloud_configuration(cfg)
        check=await mc.get_cloud_configuration()
        if check.get('IsMDMUnremovable') is not True: raise usb.SetupError('Phone did not confirm the management lock setting.')
        progress('Installing the enrollment using this PC\'s supervision identity.')
        await mc.install_profile_silent(key,data)
        profiles=await mc.get_profile_list()
        if IDENT not in profiles.get('ProfileMetadata',{}): raise Pending('Enrollment sent but not yet visible on the phone. Check the dashboard. Do not erase again.')

async def run_flow(dev, info, name, phone, options, progress, step, service=None, install=enroll, persist=save_state):
    if info.get('supervised') is None: raise usb.SetupError('Supervision is unknown. Nothing will be erased.')
    if not name.strip() or not 7 <= len(''.join(c for c in phone if c.isdigit())) <= 15: raise usb.SetupError('Enter a customer name and a phone number with 7 to 15 digits.')
    needs_erase=info['supervised'] is False and not options.get('resume')
    if options.get('resume') and info.get('pf',{}).get('setup_done') is not False and info.get('activated') is not False:
        raise usb.SetupError('Resume is only allowed when the phone is confirmed on its setup screens. No erase or restore was started.')
    if needs_erase and not (options.get('consent') and options.get('erase')=='ERASE' and options.get('backup_confirmed')):
        raise usb.SetupError('Owner consent, an independent usable backup and ERASE confirmation are required. Nothing was changed.')
    if not options.get('_mock_profile') and info.get('supervised') is True and not usb.identity_path().exists():
        raise usb.SetupError('This PC has no supervision identity. Import the original matching identity before enrolling this already supervised phone. No new identity was created.')
    profile=options.get('_mock_profile') or await asyncio.to_thread(bundled_profile)
    step(0); grant=await (service or Service()).approve(info,name,phone,progress)
    # Re-read exactly the selected phone before destructive work.
    fresh=await dev.find()
    if fresh['serial']!=info['serial']: raise usb.SetupError('The connected phone changed. Setup stopped.')
    if fresh.get('supervised') is None or (needs_erase and fresh.get('supervised') is not False): raise usb.SetupError('The supervision state changed. Check the phone again before continuing.')
    record={'udid':info['serial'],'phase':'approved','backup_dir':options.get('backup_dir'),'restore_done':bool(options.get('restore_done')),'device_id':grant.get('device_id')}
    password=options.get('password',''); usb.add_secret(password)
    usb.get_identity() if not options.get('_mock_profile') else None
    backup_dir=options.get('backup_dir')
    if options.get('resume'):
        if not options.get('_mock_profile'):
            pf=await dev.preflight()
            if pf.get('setup_done') is not False:
                raise usb.SetupError('Setup Assistant state is no longer confirmed. Resume stopped without erase or restore.')
        if not backup_dir: raise usb.SetupError('No saved backup selected. No second erase is permitted.')
        await asyncio.to_thread(usb.verify_backup, Path(backup_dir), info['serial'], password)
    elif needs_erase:
        step(1)
        if options.get('backup',True):
            b=await dev.backup_to_pc(progress,password=password); backup_dir=b['folder'];record['backup_dir']=backup_dir
        record['phase']='backup_checked';persist(record)
        # A cable swap during a long backup must never redirect the erase.
        before_erase=await dev.find()
        if before_erase.get('serial')!=info['serial'] or before_erase.get('supervised') is not False:
            raise usb.SetupError('The selected phone or supervision state changed during backup. Nothing was erased.')
        step(2);record['phase']='erase_requested';persist(record)
        await dev.erase_and_reconnect(progress);record['phase']='erased';persist(record)
    if info.get('supervised') is not True:
        step(3);await dev.activate_and_supervise(progress,show_restore=False);record['phase']='supervised';persist(record)
    if backup_dir and not options.get('restore_done'):
        step(4);progress('Restoring data, excluding management and selected settings. This is not a full identical restore.')
        await dev.restore_from_pc(backup_dir,progress,password=password);record['restore_done']=True;record['phase']='restored';persist(record)
        await dev.ensure_supervised(progress)
    step(5);await install(dev,profile,progress)
    step(6);await (service or Service()).verify(grant,progress)
    record['phase']='verified';persist(record)
    return {'supervised':True,'enrolled':True,'removal_locked':True,'filter_active':None,'backup_dir':backup_dir,'device_id':grant.get('device_id')}
