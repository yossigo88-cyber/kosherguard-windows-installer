# Build 10: owner-spare one-profile timing experiment

This is NOT a working non-removable MDM solution. Prior locked MDM and password-in-MDM tests were rejected on the spare. This build tests one distinct order: after backup and erase, activate normally, write the first USB supervision configuration with CloudConfigurationUIComplete=false, ConfigurationWasApplied=false, PostSetupProfileWasInstalled=false and no skipped setup panes, then try the unchanged locked MDM profile before manually finishing Setup Assistant. No ADE identity is claimed, no Apple activation check is bypassed, and no removable profile fallback exists.

Only the same recorded owner spare iPhone 8 is allowed. No other phone receives setup controls. A new local safety backup is mandatory; keep an independent usable backup too. Find My must be off. In the new test form confirm both boxes and type TEST ERASE. Approve the detected phone in the dashboard. ALL PHONE DATA IS ERASED. The safety backup is kept but never restored by this experiment. Stay in Setup Assistant after Wi-Fi/activation, do not finish to Home until installation result. If interrupted after the confirmed erase, the app offers CONTINUE without a second erase only at the saved erased phase. Once supervision or install has been attempted, automatic retry is blocked.

After an installed result, finish actual setup screens manually without restoring the old backup. Screenshot Settings > General > About for supervision, then Settings > General > VPN & Device Management, then the profile detail showing the full Remove Management area. If Remove Management exists, tap only to inspect the first prompt, then cancel. Do not enter a recovery password, phone passcode, or confirm removal. If any unexpected setup/Remote Management/error screen appears, stop and send that screen and the local log. Do not erase again.

An installed result means only that USB ProfileList found the one enrollment identifier. Lock, push/check-in, app hiding and DNS filtering remain UNVERIFIED. Dashboard commands need a later real device test and APNs check-in. This build does not add a DNS payload, change category settings, or handle/bundle any Cloudflare credential. Enrollment credentials are fetched at runtime from the current own-MDM ZIP and are not bundled in source or executable. No ConfigurationURL route was found in the dashboard or existing installer; this is a USB timing experiment, not automatic enrollment.

# KosherGuard desktop setup, spare-phone test build

Python/Tkinter iPhone-only app, adapted visually and in USB backup routines from the owner's v5.6.2 source. Uses admin.kosherguard.xyz and mdm.kosherguard.xyz. No third-party MDM or Android flows.

## Download and run
Download KosherGuard-Setup.exe from this release and open it on Windows. Python is not required for the executable. Apple Devices from Microsoft Store supplies the iPhone USB driver. This is an unsigned spare-phone TEST build, so Windows may show a reputation warning. Do not use on a customer's phone yet.

Built on GitHub's free standard Windows 2022 runner with Python 3.12 and PyInstaller. 38 mocked safety tests passed. The packaged executable itself launched on Windows and passed a Tkinter preview/import self-test with no USB or network calls. This is not a full interactive Windows or physical iPhone test. Screen previews were also inspected separately. Existing hosted installer was not replaced.

For a safe look without a phone: run KosherGuard-Setup.exe --preview from a terminal. For ordinary setup, double-click the executable. Read all erase/backup warnings before continuing. This does not verify the website filter or guarantee restoration/removal resistance.

## Real work and limits
Discovery reads one USB iPhone only. The user must approve the detected phone in the existing dashboard before work starts. First-time supervision requires owner consent, Find My off, an independent usable backup and typing ERASE. The selected phone is re-read before destructive work. Unknown supervision stops setup. Already supervised phones require this PC's matching supervision identity.

The existing supervision identity lives under %APPDATA%\KosherGuard\supervision-identity.pem. Back it up privately. Do not replace it to take over an already supervised phone. If the old PowerShell installer has already created a different identity beside its script, restore/copy that SAME identity to this location before managing those phones. This new ZIP includes no identity, password, token or live enrollment profile.

The enrollment profile is downloaded from the currently shipped installer URL, checked for the own-MDM endpoints, then installed using the supervision identity. A server ProfileList verification must confirm the enrollment lock before the result says management verified. iOS can reject cloud-configuration writes. A timeout does not prove failure or success. This installer does not prove that the website filter is active and does not add a DNS or VPN payload itself.

Backups are local. Integrity checks require all manifest-listed files, but cannot prove a successful restore. Restore intentionally excludes management and selected system settings and is NOT an identical restore. A full manifest copy is retained, and the original manifest is restored after the restore attempt. Keep an independent backup. No eSIM preservation guarantee; the USB erase requests preservation, but real carrier/device checks remain necessary.

Interrupted setup saves a local phase and backup folder, not the dashboard secret or backup password. Resume is offered only for the same phone on confirmed setup screens with a saved backup. It never sends another erase. If state is unclear, stop and inspect instead of guessing. The app may need the phone unlocked or setup completed before enrollment; a rejected operation stops with a clear message.

Before use with customers: full interactive Windows test, then a spare-phone backup/erase/restore/enrollment/removal test. No physical phone was touched during development.

## Tests
python -m unittest discover -s tests -v
Screenshots use --preview with sample state. They are UI previews, not evidence of real enrollment.

## Owner-only clean start for an old filter
For a spare phone that belongs to you, choose My OWN spare phone: clean start. This is a separate destructive path even when the phone reports supervised. Find My must be off. Save all needed data elsewhere and type ERASE plus OWN SPARE ERASE. Dashboard approval and same-phone checks still apply. An optional local backup is retained but NOT restored automatically. A backup from the same supervised phone can restore its old profiles/supervision.

The USB erase is an attempt, not a guaranteed way past old policy. If refused, restore using Apple Devices on Windows (recovery mode if necessary), then reconnect. Activation Lock still needs the owner's Apple Account; automated organization enrollment may return and needs its organization's release. There is no bypass. After erase, the installer requires old supervision gone, then attempts fresh supervision and own-MDM enrollment. If interrupted after a recorded erase, a separate Continue clean start (NO ERASE) is offered only for the same phone while Setup Assistant or unactivated state is confirmed. Type CONTINUE WITHOUT ERASE. It activates first, then requires old supervision confirmed gone before writing new supervision. No automatic old-backup restore and no second erase. If the state is unknown, stop for inspection. This path is mock-tested and packaged self-tested, not physically tested.

## Updates
This build checks this fixed GitHub repository for newer test-build releases when launched idle. Click Update to download and check the release asset SHA256 and size. It will not offer replacement while phone setup is running. The old executable is retained as .previous for recovery. The update helper waits for this process to close, replaces the app and relaunches. No admin prompt or paid service is required. If the app folder is not writable, replacement may fail; use the release download instead. Network failures do not block ordinary setup. Updates require one new download of this updater-enabled build first. The native packaged helper/replacement lifecycle is tested on the Windows runner, including backup bytes and child relaunch. This is not proof on every PC. A GitHub digest protects transport/integrity, not a compromised repository; this is not code signing.

Build 4 fixes checking supervision too early after erase: activation now comes before the old-supervision removal read. Unknown still stops before supervision writes or enrollment.

Build 5 fixes update restart: resets the PyInstaller environment and retries while the outer Windows executable is still locked. Failure opens a local error log. The Windows build self-test now runs the actual helper, verifies replacement and backup bytes, and launches the replaced packaged exe for a child GUI/import self-test. This is not proof on every user PC. Build 3/4 still have the old helper: manually reopen once after their update, or use the download fallback.

Build 6 shows exception type and cause even for empty errors, plus the log path. Activation instructions explain language/region, Set Up Manually and Wi-Fi while staying in Setup Assistant. Only explicit Activated state counts as activated. Unknown activation state is not treated as unactivated.

Build 7 fixes a real-phone enrollment failure: iOS refused the second cloud configuration write after our own supervision succeeded. Enrollment now verifies the matching certificate, installs the validated PayloadRemovalDisallowed profile without rewriting cloud setup, and waits for server ProfileList confirmation before claiming non-removable management. Existing phones may still fail that final lock check; a pending/failed result is not success. Future first-time supervision includes IsMDMUnremovable in its initial configuration. No extra erase is required to attempt enrollment on the already-supervised matching phone.

Build 8 adds an explicit owner-spare-only experiment: one locked MDM enrollment with the Apple profileRemovalPassword payload. It preserves PayloadRemovalDisallowed=true and never falls back to removable enrollment. Requires matching recorded clean-start phone, supervision certificate, local 12-character recovery password, and TEST. Store the password privately. The combination may be rejected. Installation is not non-removal proof; inspect Settings. No dashboard-only removal, filter-active or enrollment-check-in claim is made by the experiment. Do not use on customers. No extra erase.

# Build 11 (one flow, no backup)
Click "Set up this iPhone", enter the customer details, tick the single erase box, then "Erase and set up". Approve the phone in the dashboard when the browser opens. The app erases the phone, activates it, supervises it, installs the one KosherGuard MDM profile (PayloadRemovalDisallowed) and asks the server to confirm a check-in. No backup, no recorded-phone gate. Whether iOS keeps the profile non-removable is UNPROVEN; Apple documents that only for Business Manager enrollment. Push/instant changes are only testable after enrollment.

# Build 12 (continue on a supervised phone, no erase)
Build 11 proved erase, activation and supervision work, and that iOS refuses an MDM profile marked non-removable ("A profile containing an MDM payload must be removable"). Build 12 on an already supervised phone: installs the same enrollment profile as removable, asks the server to confirm check-in, then tests a SEPARATE non-removable restrictions profile (blocks Erase All Content and Settings and installing profiles from Settings). Whether those stop removal of the MDM profile is UNPROVEN; the app does not claim it. "Remove test restrictions" undoes the extra profile over USB. Instant push is tested by pressing Lock phone in the dashboard and timing it.

# Build 13
Adds selectable text and a "Copy all text + log" button. Decodes iOS profile errors into plain sentences. Build 12's log showed iOS refusing the removable MDM profile with "A network error has occurred" (MCInstallationErrorDomain): the profile fetches its identity from mdm.kosherguard.xyz/scep during install, so the iPhone must be online. The continue step now tells him to connect Wi-Fi first and retries 3 times.
